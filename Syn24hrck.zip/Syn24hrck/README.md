# 🛡️ SentinelPay AI

> **Tagline:** *Trust the User. Verify the Risk.*  
> **Mission:** Evaluate simulated account login and payment events with a dynamic, explainable risk score (0--100) and orchestrate targeted security responses.

---

## 📌 Executive Summary

**SentinelPay AI** is a cybersecurity SOC operations and fraud risk orchestration platform. It continuously evaluates simulated user authentication and payment telemetry against a deterministic, explainable rule engine. 

### Mandatory Automatic Behavior
The user **never** types the risk score. Adjusting any event property (such as switching location, changing device, adjusting failed login attempts, or altering transaction velocity) **immediately** recalculates the score afresh from baseline, updates the risk band, displays the exact point contributions breakdown, and recommends the corresponding security action. Turning off a signal removes its contribution without residual accumulation.

---

## ⚖️ Non-Overlapping Risk Bands & Actions

To guarantee that every integer score (0--100) maps to **exactly one** deterministic policy response, the application implements strictly non-overlapping boundaries:

| Score Range | Risk Level | Automated Policy Action | Visual Theme | Description |
| :---: | :---: | :--- | :---: | :--- |
| **0 -- 29** | **Low** | **LOW RISK --- ACTIVITY ALLOWED** | Emerald Green (`#10B981`) | No issue detected. Allow simulated activity and log to compliance trail. |
| **30 -- 49** | **Guarded** | **IN-APP NOTIFICATION** | Electric Blue (`#3B82F6`) | Deliver notice: *"Your account may be at risk. Please review this activity."* Continue monitoring. |
| **50 -- 69** | **Medium** | **START SIMULATED OTP VERIFICATION** | Warning Amber (`#F59E0B`) | Require step-up passcode. Demo code `123456`. Enforce attempt limits. On success, verify and reassess. |
| **70 -- 89** | **High** | **START SIMULATED CALL VERIFICATION** | Deep Orange (`#F97316`) | Dispatch interactive simulated voice call confirmation. Provide demo confirm/fraud/timeout controls. |
| **90 -- 100** | **Critical** | **TEMPORARILY BLOCK ACTION & LOCK ACCOUNT** | Crimson Red (`#EF4444`) | Automated circuit breaker locks synthetic demo account/session. Display evidence and controlled unlock. |

---

## ⚙️ Deterministic Signal Weights & Thresholds

Configured in `core/risk_engine.py`:

| Signal Telemetry Property | Points Contribution | Trigger Condition / Threshold |
| :--- | :---: | :--- |
| **Different / Unusual Location** | `+20` | Location == "Different" |
| **New / Unfamiliar Device** | `+10` | Device == "New" |
| **Unusual Transaction Amount** | `+15` | Amount Pattern == "Unusual" or Payment >= $5,000 |
| **Frequent Transaction Velocity** | `+15` | Frequency == "Frequent" |
| **Multiple Failed Logins** | `+20` | Failed Login Attempts >= 3 |
| **Excessive Incorrect PINs** | `+20` | Incorrect PIN Attempts >= 2 |
| **Unusual Activity Timing** | `+10` | Time Context == "Unusual" (Off-hours / nocturnal) |
| **New Payment Destination** | `+10` | Payment Destination == "New" / Untrusted Payee |

*Note: Raw scores are capped strictly at 100. If all risk signals are present, raw score = 120, normalized score = 100.*

---

## 🏗️ Project Architecture

```
d:/Syn24hrck/
├── app.py                      # Main entrypoint, navigation, global analyst session & branding
├── core/
│   ├── risk_engine.py          # Deterministic, explainable scoring engine
│   ├── responses.py            # Non-overlapping risk bands and action policies
│   ├── verification.py         # OTP, interactive Call simulation & lock state machines
│   ├── scenarios.py            # 5 one-click demonstration scenarios
│   └── ui_components.py        # Dark cybersecurity UI theme, badges & meter cards
├── data/
│   └── database.py             # SQLite persistence (accounts, events, audit logs, seed data)
├── pages/
│   ├── 1_Overview.py           # SOC Operations overview dashboard with Plotly charts
│   ├── 2_Event_Simulator.py    # Reactive simulator with real-time scoring & presets
│   ├── 3_Risk_Analysis.py      # Granular forensic telemetry and lifecycle timeline
│   ├── 4_OTP_Verification.py   # Simulated OTP verification console (Demo code: 123456)
│   ├── 5_Call_Verification.py  # Simulated voice call confirmation terminal
│   ├── 6_Temporary_Block.py    # Critical block & circuit-breaker unlock manager
│   ├── 7_Investigation.py      # SOC analyst investigation center & case labeling
│   ├── 8_Event_History.py      # Searchable, filterable audit log with CSV export
│   └── 9_Analytics.py          # Aggregate risk analytics, signal frequencies & metrics
├── tests/
│   ├── test_risk_engine.py     # Unit tests for scoring, idempotency, and boundary math
│   └── test_responses.py       # Integration tests for non-overlapping bands, OTP, Call & DB
├── requirements.txt            # Python dependencies
├── README.md                   # Complete documentation
└── .gitignore
```

---

## 🚀 Quickstart & How to Run

### 1. Prerequisites
- Python 3.10+ (tested on Python 3.14)
- Dependencies installed:
  ```bash
  pip install -r requirements.txt
  ```

### 2. Run Application
Launch SentinelPay AI using Streamlit:
```bash
streamlit run app.py
```
Open `http://localhost:8501` in your browser.

### 3. Run Test Suite
Run pytest to validate scoring boundaries, idempotency, and state persistence:
```bash
python -m pytest -v
```
*(All 27 test cases pass out of the box).*

---

## 🧪 Acceptance Test Walkthrough

To verify the primary acceptance criteria:

1. **Baseline Low Score (0/100):**
   - Navigate to **Event Simulator** (`pages/2_Event_Simulator.py`).
   - Observe baseline login with Known Device, Usual Location, 0 Failed Logins.
   - Result: Score is **0/100 (Low Risk)**, Action: `LOW RISK --- ACTIVITY ALLOWED`.
2. **Immediate Reactive Score Increase:**
   - Change Geolocation Context to **Different**.
   - Notice score immediately recalculates to **20/100 (Low Risk)** with `+20 pts Different Location` listed in the signal breakdown.
3. **Immediate Removal of Points:**
   - Switch Geolocation Context back to **Usual**.
   - Score immediately drops back to **0/100**.
4. **Trigger Guarded Notification (30/100):**
   - Click one-click preset **2. Legitimate Travel Notice** (Different Location + Unusual Time).
   - Score updates to **30/100 (Guarded)**.
5. **Trigger Medium Step-up OTP (60/100):**
   - Click **3. Step-up Payment to New Payee**.
   - Score updates to **60/100 (Medium)**. Submit the event and verify redirection to **OTP Verification Console** (Demo code `123456`).
6. **Trigger High Voice Call Verification (75/100):**
   - Click **4. Suspicious Device & Velocity**.
   - Score updates to **75/100 (High)**. Submit event and simulate IVR voice call response (Press [1] to authorize or Press [2] to report fraud).
7. **Trigger Critical Lockdown (95-100/100):**
   - Click **5. Credential Stuffing & Takeover**.
   - Score evaluates to **100/100 (Critical)**. Circuit breaker engages: action blocked and account locked.
   - Navigate to **Temporary Block** page to review dossier and execute an authorized analyst override unlock.
8. **Audit Trail & Investigation:**
   - Review all state transitions in **Event History & Audit**, export CSV, and label cases in the **Investigation Center**.

---

## 🔒 Security & Privacy Notice

- **Synthetic Data Only:** This application runs entirely on simulated demo data.
- **Zero Real Telephony / Financial Rails:** Never sends real SMS messages, dials real phone numbers, communicates with real banks, or stores real passwords/credentials.
- **Decision Support:** Risk scores provide explainable decision support and policy recommendations; they do not constitute legal proof of fraud.
