"""
SentinelPay AI - Main Application Gateway
Tagline: Trust the User. Verify the Risk.

Master entry point for SentinelPay AI. Initializes database persistence,
manages SOC analyst authentication sessions, applies cybersecurity theme,
and organizes navigation across all 9 operational modules.
"""

import streamlit as st
import os

from data.database import seed_demo_data, init_db
from core.ui_components import apply_custom_theme, render_disclaimer_footer

# Configure page metadata
st.set_page_config(
    page_title="SentinelPay AI — Trust the User. Verify the Risk.",
    page_icon="🛡️",
    layout="wide",
    initial_sidebar_state="expanded",
)

# Seed synthetic database on first startup
seed_demo_data()
apply_custom_theme()

# Session State Initialization
if "authenticated" not in st.session_state:
    st.session_state.authenticated = True  # Pre-authenticated for frictionless demo access
if "analyst_name" not in st.session_state:
    st.session_state.analyst_name = "Sarah Vance"
if "analyst_role" not in st.session_state:
    st.session_state.analyst_role = "Lead SOC Analyst"

# Sidebar Branding & Global Session Controls
with st.sidebar:
    st.markdown("""
    <div style="padding: 10px 0 16px 0;">
        <div style="font-size: 1.35rem; font-weight: 800; background: linear-gradient(135deg, #38BDF8 0%, #818CF8 50%, #C084FC 100%); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">
            🛡️ SentinelPay AI
        </div>
        <div style="font-size: 0.72rem; color: #94A3B8; text-transform: uppercase; font-weight: 600; letter-spacing: 0.05em; margin-top: 2px;">
            Trust the User. Verify the Risk.
        </div>
    </div>
    """, unsafe_allow_html=True)

    st.markdown("""
    <div style="background: rgba(245, 158, 11, 0.12); border: 1px solid rgba(245, 158, 11, 0.35); border-radius: 8px; padding: 6px 10px; margin-bottom: 16px; font-size: 0.74rem; color: #FBBF24; font-weight: 600;">
        🧪 DEMO ENVIRONMENT (SYNTHETIC)
    </div>
    """, unsafe_allow_html=True)

    st.markdown("<hr style='border: none; border-top: 1px solid rgba(255,255,255,0.08); margin: 8px 0;'>", unsafe_allow_html=True)

    # Active Analyst Drawer
    st.markdown("##### 👤 SOC Analyst Profile")
    analyst_choice = st.selectbox(
        "Active Analyst Session",
        [
            "Sarah Vance (Lead SOC Analyst)",
            "Alex Mercer (Senior Fraud Investigator)",
            "Elena Rostova (Risk Policy Auditor)",
        ],
        index=0 if "Sarah" in st.session_state.analyst_name else (1 if "Alex" in st.session_state.analyst_name else 2),
        key="analyst_selector",
    )
    if st.session_state.analyst_name not in analyst_choice:
        st.session_state.analyst_name = analyst_choice.split(" (")[0]
        st.session_state.analyst_role = analyst_choice.split(" (")[1].replace(")", "")
        st.rerun()

    st.markdown("<hr style='border: none; border-top: 1px solid rgba(255,255,255,0.08); margin: 12px 0;'>", unsafe_allow_html=True)

    # Risk Bands Quick Policy Cheatsheet
    with st.expander("📖 Risk Bands Cheatsheet", expanded=False):
        st.markdown("""
        - **0--29 (Low):** Allow & log
        - **30--49 (Guarded):** Warning notification
        - **50--69 (Medium):** Simulated OTP
        - **70--89 (High):** Simulated Call
        - **90--100 (Critical):** Circuit Breaker Lock
        """)

# Define Pages with st.navigation
pages = {
    "Operations": [
        st.Page("pages/1_Overview.py", title="Overview Dashboard", icon="📊", default=True),
        st.Page("pages/2_Event_Simulator.py", title="Event Simulator", icon="⚡"),
        st.Page("pages/3_Risk_Analysis.py", title="Risk Analysis", icon="🔬"),
    ],
    "Active Verifications": [
        st.Page("pages/4_OTP_Verification.py", title="OTP Verification", icon="📱"),
        st.Page("pages/5_Call_Verification.py", title="Call Verification", icon="📞"),
        st.Page("pages/6_Temporary_Block.py", title="Temporary Block", icon="🚫"),
    ],
    "SOC & Governance": [
        st.Page("pages/7_Investigation.py", title="Investigation Center", icon="🕵️"),
        st.Page("pages/8_Event_History.py", title="Event History & Audit", icon="📜"),
        st.Page("pages/9_Analytics.py", title="Security Analytics", icon="📈"),
    ],
}

nav = st.navigation(pages)
nav.run()
