"""
SentinelPay AI - Risk Bands and Action Policy Specification
Tagline: Trust the User. Verify the Risk.

Defines non-overlapping risk score boundaries, security action policies,
visual indicators, and audit guidelines according to specification:
  Score     Level       Required Action
  0--29     Low         No issue: allow simulated activity and log it.
  30--49    Guarded     In-app notification: "Your account may be at risk. Please review this activity." Continue monitoring.
  50--69    Medium      Start simulated OTP verification.
  70--89    High        Start simulated call verification.
  90--100   Critical    Temporarily block the attempted action and lock the synthetic demo account/session.
"""

from dataclasses import dataclass
from typing import Dict, List, Tuple


@dataclass(frozen=True)
class RiskBandInfo:
    level: str
    min_score: int
    max_score: int
    action_title: str
    action_description: str
    action_code: str
    color: str
    badge_bg: str
    badge_fg: str
    requires_step_up: bool
    is_blocked: bool
    customer_guidance: str


# Non-overlapping risk band definitions strictly covering 0 to 100
LOW_BAND = RiskBandInfo(
    level="Low",
    min_score=0,
    max_score=29,
    action_title="LOW RISK --- ACTIVITY ALLOWED",
    action_description="No issue: allow simulated activity and log it.",
    action_code="ALLOW",
    color="#10B981",          # Emerald Green
    badge_bg="rgba(16, 185, 129, 0.15)",
    badge_fg="#34D399",
    requires_step_up=False,
    is_blocked=False,
    customer_guidance="Transaction authorized automatically without interruptions.",
)

GUARDED_BAND = RiskBandInfo(
    level="Guarded",
    min_score=30,
    max_score=49,
    action_title="IN-APP NOTIFICATION",
    action_description="In-app notification: 'Your account may be at risk. Please review this activity.' Continue monitoring.",
    action_code="NOTIFICATION",
    color="#3B82F6",          # Electric / Tech Blue
    badge_bg="rgba(59, 130, 246, 0.15)",
    badge_fg="#60A5FA",
    requires_step_up=False,
    is_blocked=False,
    customer_guidance="Notice delivered to user notification feed. Activity permitted without friction.",
)

MEDIUM_BAND = RiskBandInfo(
    level="Medium",
    min_score=50,
    max_score=69,
    action_title="SIMULATED OTP VERIFICATION",
    action_description="Start simulated OTP verification. Limit attempts. On success, record verification and reassess.",
    action_code="OTP_VERIFICATION",
    color="#F59E0B",          # Warning Amber
    badge_bg="rgba(245, 158, 11, 0.15)",
    badge_fg="#FBBF24",
    requires_step_up=True,
    is_blocked=False,
    customer_guidance="One-time passcode sent to registered device (Demo test code: 123456).",
)

HIGH_BAND = RiskBandInfo(
    level="High",
    min_score=70,
    max_score=89,
    action_title="SIMULATED CALL VERIFICATION",
    action_description="Start simulated call verification. Provide demo success/failure controls. Record outcome and reassess.",
    action_code="CALL_VERIFICATION",
    color="#F97316",          # Deep Orange
    badge_bg="rgba(249, 115, 22, 0.15)",
    badge_fg="#FB923C",
    requires_step_up=True,
    is_blocked=False,
    customer_guidance="Simulated voice confirmation call dispatched to primary telephone.",
)

CRITICAL_BAND = RiskBandInfo(
    level="Critical",
    min_score=90,
    max_score=100,
    action_title="TEMPORARILY BLOCK ACTION & LOCK ACCOUNT",
    action_description="Temporarily block the attempted action and lock the synthetic demo account/session.",
    action_code="TEMPORARY_BLOCK",
    color="#EF4444",          # Crimson Red
    badge_bg="rgba(239, 68, 68, 0.15)",
    badge_fg="#F87171",
    requires_step_up=False,
    is_blocked=True,
    customer_guidance="Security hold placed on account. Security analyst review required to restore access.",
)

ALL_BANDS: List[RiskBandInfo] = [
    LOW_BAND,
    GUARDED_BAND,
    MEDIUM_BAND,
    HIGH_BAND,
    CRITICAL_BAND,
]


def get_band_for_score(score: int) -> RiskBandInfo:
    """
    Maps an integer risk score to its strictly non-overlapping risk band.
    Clamps inputs to valid 0-100 boundary.
    """
    bounded_score = max(0, min(100, int(score)))

    if bounded_score <= 29:
        return LOW_BAND
    elif bounded_score <= 49:
        return GUARDED_BAND
    elif bounded_score <= 69:
        return MEDIUM_BAND
    elif bounded_score <= 89:
        return HIGH_BAND
    else:
        return CRITICAL_BAND


def get_all_band_boundaries() -> List[Dict[str, any]]:
    """Returns documentation-ready metadata for all risk bands."""
    return [
        {
            "band": band.level,
            "range": f"{band.min_score}--{band.max_score}",
            "action": band.action_description,
            "title": band.action_title,
            "code": band.action_code,
            "color": band.color,
        }
        for band in ALL_BANDS
    ]
