"""
SentinelPay AI - Dynamic Risk Calculation Engine
Tagline: Trust the User. Verify the Risk.

Deterministic, explainable, rule-based risk scoring engine for simulated
account login and payment events. Calculates a dynamic risk score between
0 and 100 with granular signal attribution.
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any
from core.responses import get_band_for_score, RiskBandInfo

# Configurable signal weight contributions (Documented baseline values)
DEFAULT_WEIGHTS: Dict[str, int] = {
    "different_location": 20,
    "new_device": 10,
    "unusual_amount": 15,
    "frequent_transactions": 15,
    "failed_logins": 20,
    "incorrect_pins": 20,
    "unusual_time": 10,
    "new_destination": 10,
}

# Configurable threshold levels for count-based risk triggers
DEFAULT_THRESHOLDS: Dict[str, int] = {
    "failed_logins": 3,   # >= 3 failed logins triggers penalty
    "incorrect_pins": 2,  # >= 2 incorrect PIN attempts triggers penalty
    "unusual_amount_value": 5000, # Amount >= $5,000 flags unusual if not explicitly set
}


@dataclass
class RiskEvaluation:
    score: int
    raw_score: int
    band: str
    band_level: str
    action_title: str
    recommended_action: str
    action_code: str
    color: str
    triggered_signals: List[str]
    point_contributions: Dict[str, int]
    explanation: str
    requires_step_up: bool
    is_blocked: bool
    weights_applied: Dict[str, int] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "score": self.score,
            "raw_score": self.raw_score,
            "band": self.band,
            "band_level": self.band_level,
            "action_title": self.action_title,
            "recommended_action": self.recommended_action,
            "action_code": self.action_code,
            "color": self.color,
            "triggered_signals": self.triggered_signals,
            "point_contributions": self.point_contributions,
            "explanation": self.explanation,
            "requires_step_up": self.requires_step_up,
            "is_blocked": self.is_blocked,
        }


def calculate_risk(
    event_type: str = "Login",
    location: str = "Usual",
    device: str = "Known",
    amount_pattern: str = "Usual",
    frequency: str = "Normal",
    failed_logins: int = 0,
    incorrect_pins: int = 0,
    time_context: str = "Usual",
    payment_destination: str = "Known",
    amount: float = 0.0,
    custom_weights: Optional[Dict[str, int]] = None,
    custom_thresholds: Optional[Dict[str, int]] = None,
) -> RiskEvaluation:
    """
    Deterministic risk calculation engine.

    Evaluates event telemetry signals against documented weights and thresholds.
    Score is bounded strictly between 0 and 100.
    Recalculates afresh from input properties with zero hidden memory or cumulative drift.
    """
    weights = dict(DEFAULT_WEIGHTS)
    if custom_weights:
        weights.update(custom_weights)

    thresholds = dict(DEFAULT_THRESHOLDS)
    if custom_thresholds:
        thresholds.update(custom_thresholds)

    score = 0
    triggered_signals: List[str] = []
    point_contributions: Dict[str, int] = {}

    # 1. Location signal (+20)
    if location.lower() in ("different", "unusual", "new"):
        pts = weights.get("different_location", 20)
        score += pts
        triggered_signals.append("Different / Unusual Location")
        point_contributions["Different Location"] = pts

    # 2. Device signal (+10)
    if device.lower() in ("new", "unfamiliar", "unknown"):
        pts = weights.get("new_device", 10)
        score += pts
        triggered_signals.append("New / Unfamiliar Device")
        point_contributions["New Device"] = pts

    # 3. Transaction Amount signal (+15)
    # Check either amount pattern flag or monetary threshold
    is_unusual_amount = amount_pattern.lower() in ("unusual", "suspicious", "high") or (
        amount >= thresholds.get("unusual_amount_value", 5000) and event_type.lower() == "payment"
    )
    if is_unusual_amount:
        pts = weights.get("unusual_amount", 15)
        score += pts
        label = "Unusual Transaction Amount"
        if amount > 0:
            label += f" (${amount:,.2f})"
        triggered_signals.append(label)
        point_contributions["Unusual Amount"] = pts

    # 4. Recent Transaction Frequency signal (+15)
    if frequency.lower() in ("frequent", "high", "burst"):
        pts = weights.get("frequent_transactions", 15)
        score += pts
        triggered_signals.append("Frequent Transaction Velocity")
        point_contributions["Frequent Transactions"] = pts

    # 5. Multiple Failed Login Attempts (+20 for >= threshold)
    fl_count = max(0, int(failed_logins))
    fl_threshold = thresholds.get("failed_logins", 3)
    if fl_count >= fl_threshold:
        pts = weights.get("failed_logins", 20)
        score += pts
        triggered_signals.append(f"Multiple Failed Logins ({fl_count} attempts >= {fl_threshold} threshold)")
        point_contributions[f"Failed Logins ({fl_count})"] = pts

    # 6. Too Many Incorrect PIN Attempts (+20 for >= threshold)
    pin_count = max(0, int(incorrect_pins))
    pin_threshold = thresholds.get("incorrect_pins", 2)
    if pin_count >= pin_threshold:
        pts = weights.get("incorrect_pins", 20)
        score += pts
        triggered_signals.append(f"Too Many Incorrect PIN Attempts ({pin_count} attempts >= {pin_threshold} threshold)")
        point_contributions[f"Incorrect PINs ({pin_count})"] = pts

    # 7. Unusual Login/Activity Time (+10)
    if time_context.lower() in ("unusual", "off-hours", "night"):
        pts = weights.get("unusual_time", 10)
        score += pts
        triggered_signals.append("Unusual Activity Time (Off-hours / Anomaly)")
        point_contributions["Unusual Time"] = pts

    # 8. New Payment Destination (+10)
    if payment_destination.lower() in ("new", "unknown", "unregistered"):
        pts = weights.get("new_destination", 10)
        score += pts
        triggered_signals.append("New Payment Destination / Untrusted Payee")
        point_contributions["New Destination"] = pts

    raw_score = score
    normalized_score = max(0, min(100, int(score)))

    # Get mapped risk band and policy response
    band_info: RiskBandInfo = get_band_for_score(normalized_score)

    # Generate transparent explanation
    if normalized_score == 0:
        explanation = (
            "All event telemetry signals align with normal synthetic user baseline. "
            "No risk factors identified. Activity authorized without step-up authentication."
        )
    else:
        signals_summary = ", ".join(
            [f"{sig} (+{pts} pts)" for sig, pts in point_contributions.items()]
        )
        capped_note = f" (raw score {raw_score} capped at 100)" if raw_score > 100 else ""
        explanation = (
            f"Risk score evaluated at {normalized_score}/100 [{band_info.level.upper()} RISK]{capped_note}. "
            f"Triggered {len(triggered_signals)} risk signal(s): {signals_summary}. "
            f"Automated policy recommendation: {band_info.action_title}."
        )

    return RiskEvaluation(
        score=normalized_score,
        raw_score=raw_score,
        band=band_info.level,
        band_level=band_info.level,
        action_title=band_info.action_title,
        recommended_action=band_info.action_description,
        action_code=band_info.action_code,
        color=band_info.color,
        triggered_signals=triggered_signals,
        point_contributions=point_contributions,
        explanation=explanation,
        requires_step_up=band_info.requires_step_up,
        is_blocked=band_info.is_blocked,
        weights_applied=weights,
    )
