"""
SentinelPay AI - One-Click Demonstration Scenarios
Tagline: Trust the User. Verify the Risk.

Pre-configured realistic synthetic test scenarios designed for one-click
demonstrations of each risk band: Low, Guarded, Medium, High, and Critical.
"""

from typing import Dict, Any, List

SCENARIOS: List[Dict[str, Any]] = [
    {
        "id": "scenario_normal_login",
        "name": "1. Normal Everyday Login (Low Risk: Score 0)",
        "target_band": "Low",
        "badge_color": "#10B981",
        "description": "Synthetic user signs in from everyday laptop and usual home city. No failed logins or anomalies.",
        "params": {
            "event_type": "Login",
            "account_id": "ACC-84920",
            "location": "Usual",
            "device": "Known",
            "amount_pattern": "Usual",
            "frequency": "Normal",
            "failed_logins": 0,
            "incorrect_pins": 0,
            "time_context": "Usual",
            "payment_destination": "Known",
            "amount": 0.0,
            "notes": "Routine morning sign-in from recognized residential IP in Chicago.",
        },
    },
    {
        "id": "scenario_guarded_travel",
        "name": "2. Legitimate Travel Notice (Guarded: Score 30)",
        "target_band": "Guarded",
        "badge_color": "#3B82F6",
        "description": "User checks in from a hotel abroad at an odd hour. Low-level warning banner shown; activity allowed.",
        "params": {
            "event_type": "Login",
            "account_id": "ACC-19342",
            "location": "Different",      # +20
            "device": "Known",
            "amount_pattern": "Usual",
            "frequency": "Normal",
            "failed_logins": 0,
            "incorrect_pins": 0,
            "time_context": "Unusual",      # +10 => Total 30 (Guarded)
            "payment_destination": "Known",
            "amount": 0.0,
            "notes": "Sign-in from Tokyo hotel Wi-Fi at 03:30 AM local time on known primary phone.",
        },
    },
    {
        "id": "scenario_medium_payment",
        "name": "3. Step-up Payment to New Payee (Medium: Score 60)",
        "target_band": "Medium",
        "badge_color": "#F59E0B",
        "description": "Sudden payment from new location to an unfamiliar payee. Requires simulated OTP passcode.",
        "params": {
            "event_type": "Payment",
            "account_id": "ACC-77215",
            "location": "Different",        # +20
            "device": "Known",
            "amount_pattern": "Unusual",    # +15
            "frequency": "Frequent",        # +15
            "failed_logins": 0,
            "incorrect_pins": 0,
            "time_context": "Usual",
            "payment_destination": "New",   # +10 => Total 60 (Medium)
            "amount": 1450.0,
            "notes": "Spike in transaction velocity with a payment to an unregistered peer-to-peer account.",
        },
    },
    {
        "id": "scenario_high_phone_verify",
        "name": "4. Suspicious Device & Velocity (High: Score 75)",
        "target_band": "High",
        "badge_color": "#F97316",
        "description": "Brand new device, unfamiliar city, prior failed attempts, and odd timing. Simulated call verification triggered.",
        "params": {
            "event_type": "Payment",
            "account_id": "ACC-30491",
            "location": "Different",        # +20
            "device": "New",                # +10
            "amount_pattern": "Unusual",    # +15
            "frequency": "Normal",
            "failed_logins": 3,             # +20 (threshold >= 3)
            "incorrect_pins": 0,
            "time_context": "Unusual",      # +10 => Total 75 (High)
            "payment_destination": "Known",
            "amount": 3200.0,
            "notes": "Connection from unmanaged browser after 3 failed login attempts. Voice call confirmation dispatched.",
        },
    },
    {
        "id": "scenario_critical_lock",
        "name": "5. Credential Stuffing & Takeover (Critical: Score 95+ -> Block)",
        "target_band": "Critical",
        "badge_color": "#EF4444",
        "description": "Massive credential brute force + new payee + unfamiliar hardware. Automatic demo block and account lockdown.",
        "params": {
            "event_type": "Payment",
            "account_id": "ACC-55102",
            "location": "Different",        # +20
            "device": "New",                # +10
            "amount_pattern": "Unusual",    # +15
            "frequency": "Frequent",        # +15
            "failed_logins": 4,             # +20
            "incorrect_pins": 3,            # +20
            "time_context": "Unusual",      # +10
            "payment_destination": "New",   # +10 => Total 120 -> Capped at 100 (Critical)
            "amount": 9850.0,
            "notes": "Suspected automated bot credential attack attempting wire drain. Immediate circuit breaker engaged.",
        },
    },
]


def get_scenario_by_id(scenario_id: str) -> Dict[str, Any]:
    for sc in SCENARIOS:
        if sc["id"] == scenario_id:
            return sc
    return SCENARIOS[0]
