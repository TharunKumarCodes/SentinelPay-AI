"""
SentinelPay AI - Shared Cybersecurity UI Component Library
Tagline: Trust the User. Verify the Risk.

Provides dark-mode styling tokens, persistent cybersecurity top navigation,
status indicators, risk meters, and compliance disclaimers across all pages.
"""

import streamlit as st
from datetime import datetime
from typing import Dict, Any, List, Optional
from core.responses import get_band_for_score
from data.database import get_dashboard_counts, get_all_accounts


def apply_custom_theme() -> None:
    """Injects high-contrast, accessible dark cybersecurity design system CSS."""
    st.markdown("""
    <style>
    /* Google Fonts Import */
    @import url('https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;600;700&family=Outfit:wght@300;400;500;600;700;800&display=swap');

    /* Global Dark Theme Overrides */
    html, body, [class*="st-emotion-cache"] {
        font-family: 'Outfit', sans-serif;
    }

    code, kbd, samp, pre, .mono {
        font-family: 'JetBrains Mono', monospace !important;
    }

    /* Main background accents */
    .stApp {
        background: linear-gradient(180deg, #090D16 0%, #0D1322 50%, #0A0E1A 100%);
        color: #F1F5F9;
    }

    /* Sidebar aesthetics */
    [data-testid="stSidebar"] {
        background: #0B0F19 !important;
        border-right: 1px solid rgba(59, 130, 246, 0.15);
    }

    /* Header styling */
    .sentinel-header {
        background: rgba(17, 24, 39, 0.75);
        backdrop-filter: blur(12px);
        -webkit-backdrop-filter: blur(12px);
        border: 1px solid rgba(255, 255, 255, 0.08);
        border-radius: 12px;
        padding: 16px 24px;
        margin-bottom: 24px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        flex-wrap: wrap;
        gap: 12px;
    }

    .brand-title {
        font-size: 1.55rem;
        font-weight: 800;
        letter-spacing: -0.02em;
        background: linear-gradient(135deg, #38BDF8 0%, #818CF8 50%, #C084FC 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        margin: 0;
        display: flex;
        align-items: center;
        gap: 8px;
    }

    .brand-tagline {
        font-size: 0.82rem;
        color: #94A3B8;
        font-weight: 500;
        letter-spacing: 0.04em;
        text-transform: uppercase;
        margin-top: 2px;
    }

    /* Badges */
    .demo-pill {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        background: rgba(245, 158, 11, 0.12);
        border: 1px solid rgba(245, 158, 11, 0.35);
        color: #FBBF24;
        font-size: 0.75rem;
        font-weight: 600;
        padding: 4px 10px;
        border-radius: 9999px;
        letter-spacing: 0.05em;
        text-transform: uppercase;
    }

    .analyst-pill {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        background: rgba(59, 130, 246, 0.12);
        border: 1px solid rgba(59, 130, 246, 0.3);
        color: #60A5FA;
        font-size: 0.78rem;
        font-weight: 500;
        padding: 4px 12px;
        border-radius: 9999px;
    }

    .lock-pill {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        background: rgba(239, 68, 68, 0.15);
        border: 1px solid rgba(239, 68, 68, 0.4);
        color: #F87171;
        font-size: 0.75rem;
        font-weight: 600;
        padding: 4px 10px;
        border-radius: 9999px;
        animation: pulse 2s infinite;
    }

    @keyframes pulse {
        0%, 100% { opacity: 1; }
        50% { opacity: 0.6; }
    }

    /* Metric Card */
    .metric-card {
        background: rgba(17, 24, 39, 0.65);
        border: 1px solid rgba(255, 255, 255, 0.07);
        border-radius: 12px;
        padding: 16px 20px;
        transition: transform 0.2s ease, border-color 0.2s ease;
    }
    .metric-card:hover {
        transform: translateY(-2px);
        border-color: rgba(56, 189, 248, 0.3);
    }
    .metric-label {
        font-size: 0.8rem;
        color: #94A3B8;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.05em;
    }
    .metric-value {
        font-size: 1.85rem;
        font-weight: 800;
        color: #F8FAFC;
        margin: 4px 0;
    }
    .metric-sub {
        font-size: 0.75rem;
        color: #64748B;
    }

    /* Live Risk Meter Card */
    .risk-preview-box {
        background: rgba(15, 23, 42, 0.85);
        border: 1px solid rgba(255, 255, 255, 0.1);
        border-radius: 14px;
        padding: 20px;
        box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.4);
    }

    .risk-score-display {
        font-size: 3.5rem;
        font-weight: 900;
        line-height: 1;
        letter-spacing: -0.04em;
    }

    /* Signal Breakdown pill */
    .signal-tag {
        display: inline-flex;
        align-items: center;
        justify-content: space-between;
        width: 100%;
        background: rgba(30, 41, 59, 0.7);
        border-left: 3px solid #38BDF8;
        border-radius: 6px;
        padding: 8px 12px;
        margin-bottom: 6px;
        font-size: 0.85rem;
        color: #E2E8F0;
    }
    .signal-points {
        font-family: 'JetBrains Mono', monospace;
        font-weight: 700;
        color: #38BDF8;
        background: rgba(56, 189, 248, 0.12);
        padding: 2px 8px;
        border-radius: 4px;
    }

    /* Streamlit widget tweaks */
    div[data-testid="stMetricValue"] {
        font-family: 'Outfit', sans-serif !important;
        font-weight: 800 !important;
    }
    .stButton>button {
        border-radius: 8px !important;
        font-weight: 600 !important;
        transition: all 0.2s ease !important;
    }
    .stButton>button:hover {
        transform: translateY(-1px) !important;
        box-shadow: 0 4px 12px rgba(59, 130, 246, 0.25) !important;
    }

    /* Hackathon prototype disclaimer bar */
    .disclaimer-bar {
        margin-top: 40px;
        padding: 14px 20px;
        background: rgba(15, 23, 42, 0.5);
        border: 1px dashed rgba(148, 163, 184, 0.2);
        border-radius: 8px;
        color: #64748B;
        font-size: 0.75rem;
        text-align: center;
        line-height: 1.5;
    }
    </style>
    """, unsafe_allow_html=True)


def init_session_state() -> None:
    """Initializes global session states for analyst identity, simulated events, etc."""
    if "analyst_name" not in st.session_state:
        st.session_state.analyst_name = "Sarah Vance"
    if "analyst_role" not in st.session_state:
        st.session_state.analyst_role = "Lead SOC Analyst"
    if "authenticated" not in st.session_state:
        st.session_state.authenticated = True  # Demo pre-authenticated by default
    if "active_event_id" not in st.session_state:
        st.session_state.active_event_id = None
    if "simulator_params" not in st.session_state:
        st.session_state.simulator_params = None


def render_header() -> None:
    """Renders the top branding and global status bar."""
    init_session_state()
    counts = get_dashboard_counts()
    locked_count = counts.get("locked_accounts", 0)

    col1, col2 = st.columns([3, 2])
    with col1:
        st.markdown(f"""
        <div>
            <div class="brand-title">🛡️ SentinelPay AI</div>
            <div class="brand-tagline">Trust the User. Verify the Risk.</div>
        </div>
        """, unsafe_allow_html=True)

    with col2:
        lock_html = (
            f"""<span class="lock-pill">🔒 {locked_count} Demo Account(s) Locked</span>"""
            if locked_count > 0
            else ""
        )
        st.markdown(f"""
        <div style="display: flex; justify-content: flex-end; align-items: center; gap: 10px; height: 100%;">
            {lock_html}
            <span class="demo-pill">🧪 Synthetic Demo Environment</span>
            <span class="analyst-pill">👤 {st.session_state.analyst_name}</span>
        </div>
        """, unsafe_allow_html=True)

    st.markdown("<hr style='border: none; border-top: 1px solid rgba(255,255,255,0.08); margin: 12px 0 20px 0;'>", unsafe_allow_html=True)


def render_disclaimer_footer() -> None:
    """Displays mandatory hackathon demo & prototype disclaimer."""
    st.markdown("""
    <div class="disclaimer-bar">
        ⚖️ <strong>SentinelPay AI Security Prototype Notice:</strong>
        This is an educational cybersecurity hackathon demonstration running on isolated synthetic test data.
        Never connects to real SMS carriers, phone telephony networks, real banking rails, or customer accounts.
        Dynamic risk scores represent explainable decision-support signals, not conclusive legal proof of fraud.
    </div>
    """, unsafe_allow_html=True)


def get_band_badge_html(band: str, score: Optional[int] = None) -> str:
    """Returns styled HTML pill for risk band."""
    colors = {
        "Low": ("#10B981", "rgba(16, 185, 129, 0.15)"),
        "Guarded": ("#3B82F6", "rgba(59, 130, 246, 0.15)"),
        "Medium": ("#F59E0B", "rgba(245, 158, 11, 0.15)"),
        "High": ("#F97316", "rgba(249, 115, 22, 0.15)"),
        "Critical": ("#EF4444", "rgba(239, 68, 68, 0.15)"),
    }
    fg, bg = colors.get(band, ("#94A3B8", "rgba(148, 163, 184, 0.15)"))
    score_str = f" ({score})" if score is not None else ""
    return f"""<span style="display: inline-block; background: {bg}; border: 1px solid {fg}; color: {fg}; font-size: 0.76rem; font-weight: 700; padding: 2px 10px; border-radius: 6px; letter-spacing: 0.04em;">{band.upper()}{score_str}</span>"""
