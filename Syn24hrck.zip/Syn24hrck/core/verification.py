"""
SentinelPay AI - Verification & Security Workflow Engine
Tagline: Trust the User. Verify the Risk.

Handles simulated OTP verification, simulated voice call confirmation,
and account temporary lock/unlock state machines. Never interacts with
real telephony, SMS gateways, real banking rails, or customer credentials.
"""

from dataclasses import dataclass
from typing import Dict, Any, Optional, Tuple
from datetime import datetime

# Standard demo OTP passcode clearly documented for testing
DEMO_OTP_CODE = "123456"
MAX_OTP_ATTEMPTS = 3


@dataclass
class OTPVerificationResult:
    success: bool
    status: str
    message: str
    attempts_used: int
    attempts_remaining: int
    is_exhausted: bool


def verify_otp_attempt(input_code: str, attempts_used: int) -> OTPVerificationResult:
    """
    Validates a simulated OTP code against synthetic demo passcode.
    Enforces maximum attempt limiter.
    """
    cleaned_code = str(input_code).strip()
    new_attempts = attempts_used + 1
    attempts_left = max(0, MAX_OTP_ATTEMPTS - new_attempts)

    if cleaned_code == DEMO_OTP_CODE:
        return OTPVerificationResult(
            success=True,
            status="VERIFIED",
            message="Passcode verified successfully. Identity step-up authentication passed.",
            attempts_used=new_attempts,
            attempts_remaining=attempts_left,
            is_exhausted=False,
        )

    is_exhausted = new_attempts >= MAX_OTP_ATTEMPTS
    status = "EXHAUSTED" if is_exhausted else "FAILED"
    msg = (
        "Max verification attempts exceeded. Action blocked and escalated to fraud investigation."
        if is_exhausted
        else f"Invalid demo passcode entered. {attempts_left} attempt(s) remaining."
    )

    return OTPVerificationResult(
        success=False,
        status=status,
        message=msg,
        attempts_used=new_attempts,
        attempts_remaining=attempts_left,
        is_exhausted=is_exhausted,
    )


# Simulated Voice Call states
CALL_STATUSES = [
    "IDLE",
    "WAITING_FOR_CONFIRMATION",
    "RINGING",
    "CONNECTED",
    "VERIFIED",
    "VERIFICATION_FAILED",
    "TIMED_OUT",
    "FRAUD_REPORTED",
]


@dataclass
class CallSimulationResult:
    status: str
    title: str
    message: str
    is_terminal: bool
    is_success: bool


def handle_call_simulation_action(action: str) -> CallSimulationResult:
    """
    State machine for simulated interactive voice call verification.
    """
    act = action.upper()
    if act in ("CONFIRM", "PRESS_1", "APPROVE"):
        return CallSimulationResult(
            status="VERIFIED",
            title="Call Verified by Synthetic Account Holder",
            message="User answered the simulated verification call and pressed [1] to authorize the transaction.",
            is_terminal=True,
            is_success=True,
        )
    elif act in ("REJECT", "PRESS_2", "REPORT_FRAUD"):
        return CallSimulationResult(
            status="FRAUD_REPORTED",
            title="Fraud Alert Triggered by User via Call",
            message="User answered the simulated call and pressed [2] to flag unauthorized access! Account automatically locked.",
            is_terminal=True,
            is_success=False,
        )
    elif act in ("TIMEOUT", "NO_ANSWER"):
        return CallSimulationResult(
            status="VERIFICATION_FAILED",
            title="Call Timed Out / No Answer",
            message="Simulated call timed out after 45 seconds without customer confirmation. Transaction kept in pending review.",
            is_terminal=True,
            is_success=False,
        )
    elif act in ("START", "DIAL"):
        return CallSimulationResult(
            status="WAITING_FOR_CONFIRMATION",
            title="Simulated Voice Call Dispatched",
            message="Dialing primary synthetic registered telephone (+1-555-0199)... Waiting for simulated user response.",
            is_terminal=False,
            is_success=False,
        )
    else:
        return CallSimulationResult(
            status="WAITING_FOR_CONFIRMATION",
            title="Waiting for Call Response",
            message="Simulated call line open. Awaiting user input selection.",
            is_terminal=False,
            is_success=False,
        )
