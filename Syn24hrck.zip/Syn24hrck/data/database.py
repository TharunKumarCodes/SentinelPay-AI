"""
SentinelPay AI - Database Persistence Layer (SQLite)
Tagline: Trust the User. Verify the Risk.

Provides thread-safe persistence for synthetic accounts, evaluated security events,
verification lifecycles, and immutable audit logs using SQLite.
"""

import sqlite3
import json
import os
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional, Tuple

DB_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "sentinelpay.db")


def get_connection() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH, check_same_thread=False, timeout=15.0)
    conn.row_factory = sqlite3.Row
    return conn


def init_db() -> None:
    """Initializes tables for accounts, security events, and audit logs."""
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS accounts (
        account_id TEXT PRIMARY KEY,
        user_name TEXT NOT NULL,
        email TEXT NOT NULL,
        phone TEXT NOT NULL,
        is_locked INTEGER DEFAULT 0,
        lock_reason TEXT DEFAULT '',
        lock_timestamp TEXT DEFAULT '',
        created_at TEXT NOT NULL
    )
    """)

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS events (
        event_id TEXT PRIMARY KEY,
        timestamp TEXT NOT NULL,
        account_id TEXT NOT NULL,
        event_type TEXT NOT NULL,
        amount REAL DEFAULT 0.0,
        payment_destination TEXT DEFAULT '',
        location_status TEXT DEFAULT 'Usual',
        device_status TEXT DEFAULT 'Known',
        amount_pattern TEXT DEFAULT 'Usual',
        frequency_status TEXT DEFAULT 'Normal',
        failed_logins INTEGER DEFAULT 0,
        incorrect_pins INTEGER DEFAULT 0,
        time_status TEXT DEFAULT 'Usual',
        destination_status TEXT DEFAULT 'Known',
        notes TEXT DEFAULT '',
        risk_score INTEGER NOT NULL,
        raw_score INTEGER NOT NULL,
        risk_band TEXT NOT NULL,
        triggered_signals TEXT NOT NULL,
        point_contributions TEXT NOT NULL,
        explanation TEXT NOT NULL,
        recommended_action TEXT NOT NULL,
        action_code TEXT NOT NULL,
        verification_status TEXT NOT NULL,
        resolution_outcome TEXT DEFAULT 'Unresolved',
        analyst_notes TEXT DEFAULT '',
        updated_at TEXT NOT NULL,
        FOREIGN KEY(account_id) REFERENCES accounts(account_id)
    )
    """)

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS audit_logs (
        log_id INTEGER PRIMARY KEY AUTOINCREMENT,
        timestamp TEXT NOT NULL,
        event_id TEXT DEFAULT '',
        account_id TEXT DEFAULT '',
        action_type TEXT NOT NULL,
        analyst TEXT NOT NULL,
        details TEXT NOT NULL
    )
    """)

    conn.commit()
    conn.close()


def add_audit_log(
    action_type: str,
    details: str,
    analyst: str = "System Automated",
    event_id: str = "",
    account_id: str = "",
) -> int:
    """Records an audit trail entry."""
    conn = get_connection()
    cursor = conn.cursor()
    now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    cursor.execute("""
    INSERT INTO audit_logs (timestamp, event_id, account_id, action_type, analyst, details)
    VALUES (?, ?, ?, ?, ?, ?)
    """, (now_str, event_id, account_id, action_type, analyst, details))

    conn.commit()
    log_id = cursor.lastrowid
    conn.close()
    return log_id


def save_event(
    event_id: str,
    account_id: str,
    event_type: str,
    amount: float,
    payment_destination: str,
    location_status: str,
    device_status: str,
    amount_pattern: str,
    frequency_status: str,
    failed_logins: int,
    incorrect_pins: int,
    time_status: str,
    destination_status: str,
    notes: str,
    risk_score: int,
    raw_score: int,
    risk_band: str,
    triggered_signals: List[str],
    point_contributions: Dict[str, int],
    explanation: str,
    recommended_action: str,
    action_code: str,
    analyst_name: str = "System",
) -> str:
    """Saves a newly evaluated event and triggers corresponding security actions."""
    conn = get_connection()
    cursor = conn.cursor()
    now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    # Determine initial verification status based on risk band action code
    if action_code == "ALLOW":
        verification_status = "ACTIVITY_ALLOWED"
    elif action_code == "NOTIFICATION":
        verification_status = "NOTIFICATION_SENT"
    elif action_code == "OTP_VERIFICATION":
        verification_status = "PENDING_OTP"
    elif action_code == "CALL_VERIFICATION":
        verification_status = "PENDING_CALL"
    elif action_code == "TEMPORARY_BLOCK":
        verification_status = "BLOCKED"
    else:
        verification_status = "PENDING_REVIEW"

    cursor.execute("""
    INSERT OR REPLACE INTO events (
        event_id, timestamp, account_id, event_type, amount, payment_destination,
        location_status, device_status, amount_pattern, frequency_status,
        failed_logins, incorrect_pins, time_status, destination_status,
        notes, risk_score, raw_score, risk_band, triggered_signals,
        point_contributions, explanation, recommended_action, action_code,
        verification_status, resolution_outcome, analyst_notes, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        event_id, now_str, account_id, event_type, amount, payment_destination,
        location_status, device_status, amount_pattern, frequency_status,
        failed_logins, incorrect_pins, time_status, destination_status,
        notes, risk_score, raw_score, risk_band,
        json.dumps(triggered_signals), json.dumps(point_contributions),
        explanation, recommended_action, action_code,
        verification_status, "Unresolved", "", now_str
    ))

    # If critical risk, automatically lock the account
    if action_code == "TEMPORARY_BLOCK":
        cursor.execute("""
        UPDATE accounts
        SET is_locked = 1,
            lock_reason = ?,
            lock_timestamp = ?
        WHERE account_id = ?
        """, (f"Critical risk score ({risk_score}/100) triggered automatic lock on event {event_id}", now_str, account_id))

    conn.commit()
    conn.close()

    # Log audit entry
    add_audit_log(
        action_type="EVENT_SUBMITTED",
        details=f"Event {event_id} ({event_type}) evaluated with score {risk_score} [{risk_band}]. Action: {action_code}. Status: {verification_status}",
        analyst=analyst_name,
        event_id=event_id,
        account_id=account_id,
    )

    if action_code == "TEMPORARY_BLOCK":
        add_audit_log(
            action_type="ACCOUNT_LOCKED",
            details=f"Demo account {account_id} locked automatically due to critical risk score {risk_score}/100.",
            analyst="SentinelPay Circuit Breaker",
            event_id=event_id,
            account_id=account_id,
        )

    return event_id


def update_event_verification(
    event_id: str,
    new_verification_status: str,
    analyst_name: str,
    audit_notes: str,
    is_success: bool = False,
) -> None:
    """Updates verification status and records an audit log entry."""
    conn = get_connection()
    cursor = conn.cursor()
    now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    cursor.execute("""
    UPDATE events
    SET verification_status = ?,
        updated_at = ?
    WHERE event_id = ?
    """, (new_verification_status, now_str, event_id))

    cursor.execute("SELECT account_id, risk_score FROM events WHERE event_id = ?", (event_id,))
    row = cursor.fetchone()
    account_id = row["account_id"] if row else ""
    score = row["risk_score"] if row else 0

    conn.commit()
    conn.close()

    add_audit_log(
        action_type="VERIFICATION_UPDATE",
        details=f"Verification status changed to '{new_verification_status}'. Note: {audit_notes}",
        analyst=analyst_name,
        event_id=event_id,
        account_id=account_id,
    )


def update_investigation_resolution(
    event_id: str,
    resolution_outcome: str,
    analyst_notes: str,
    analyst_name: str,
) -> None:
    """Updates analyst investigation outcome (Confirmed Fraud, Legitimate, Unresolved)."""
    conn = get_connection()
    cursor = conn.cursor()
    now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    cursor.execute("""
    UPDATE events
    SET resolution_outcome = ?,
        analyst_notes = ?,
        updated_at = ?
    WHERE event_id = ?
    """, (resolution_outcome, analyst_notes, now_str, event_id))

    cursor.execute("SELECT account_id FROM events WHERE event_id = ?", (event_id,))
    row = cursor.fetchone()
    account_id = row["account_id"] if row else ""

    conn.commit()
    conn.close()

    add_audit_log(
        action_type="ANALYST_INVESTIGATION",
        details=f"Analyst {analyst_name} classified event as '{resolution_outcome}'. Analyst notes: {analyst_notes}",
        analyst=analyst_name,
        event_id=event_id,
        account_id=account_id,
    )


def lock_account(account_id: str, reason: str, analyst_name: str = "Analyst") -> None:
    """Explicitly locks a demo account."""
    conn = get_connection()
    cursor = conn.cursor()
    now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    cursor.execute("""
    UPDATE accounts
    SET is_locked = 1,
        lock_reason = ?,
        lock_timestamp = ?
    WHERE account_id = ?
    """, (reason, now_str, account_id))

    conn.commit()
    conn.close()

    add_audit_log(
        action_type="MANUAL_ACCOUNT_LOCK",
        details=f"Demo account {account_id} locked by {analyst_name}. Reason: {reason}",
        analyst=analyst_name,
        account_id=account_id,
    )


def unlock_account(account_id: str, reason: str, analyst_name: str = "Analyst") -> None:
    """Explicitly unlocks a demo account."""
    conn = get_connection()
    cursor = conn.cursor()
    now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    cursor.execute("""
    UPDATE accounts
    SET is_locked = 0,
        lock_reason = '',
        lock_timestamp = ''
    WHERE account_id = ?
    """, (account_id,))

    conn.commit()
    conn.close()

    add_audit_log(
        action_type="ACCOUNT_UNLOCKED",
        details=f"Demo account {account_id} restored/unlocked by {analyst_name}. Reason: {reason}",
        analyst=analyst_name,
        account_id=account_id,
    )


def get_all_accounts() -> List[Dict[str, Any]]:
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM accounts ORDER BY account_id ASC")
    rows = [dict(r) for r in cursor.fetchall()]
    conn.close()
    return rows


def get_account(account_id: str) -> Optional[Dict[str, Any]]:
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM accounts WHERE account_id = ?", (account_id,))
    row = cursor.fetchone()
    conn.close()
    return dict(row) if row else None


def get_all_events(limit: int = 200) -> List[Dict[str, Any]]:
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM events ORDER BY timestamp DESC LIMIT ?", (limit,))
    rows = [dict(r) for r in cursor.fetchall()]
    conn.close()

    for r in rows:
        try:
            r["triggered_signals"] = json.loads(r["triggered_signals"])
        except Exception:
            r["triggered_signals"] = []
        try:
            r["point_contributions"] = json.loads(r["point_contributions"])
        except Exception:
            r["point_contributions"] = {}

    return rows


def get_event_by_id(event_id: str) -> Optional[Dict[str, Any]]:
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM events WHERE event_id = ?", (event_id,))
    row = cursor.fetchone()
    conn.close()
    if not row:
        return None
    r = dict(row)
    try:
        r["triggered_signals"] = json.loads(r["triggered_signals"])
    except Exception:
        r["triggered_signals"] = []
    try:
        r["point_contributions"] = json.loads(r["point_contributions"])
    except Exception:
        r["point_contributions"] = {}
    return r


def get_audit_logs(event_id: Optional[str] = None, account_id: Optional[str] = None, limit: int = 150) -> List[Dict[str, Any]]:
    conn = get_connection()
    cursor = conn.cursor()
    query = "SELECT * FROM audit_logs WHERE 1=1"
    params = []
    if event_id:
        query += " AND event_id = ?"
        params.append(event_id)
    if account_id:
        query += " AND account_id = ?"
        params.append(account_id)
    query += " ORDER BY log_id DESC LIMIT ?"
    params.append(limit)

    cursor.execute(query, tuple(params))
    rows = [dict(r) for r in cursor.fetchall()]
    conn.close()
    return rows


def get_dashboard_counts() -> Dict[str, Any]:
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("SELECT COUNT(*) FROM events")
    total_events = cursor.fetchone()[0]

    cursor.execute("SELECT risk_band, COUNT(*) FROM events GROUP BY risk_band")
    band_counts = {r[0]: r[1] for r in cursor.fetchall()}

    cursor.execute("SELECT COUNT(*) FROM events WHERE verification_status IN ('PENDING_OTP', 'PENDING_CALL')")
    pending_verifications = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(*) FROM accounts WHERE is_locked = 1")
    locked_accounts = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(*) FROM events WHERE resolution_outcome = 'Unresolved' AND risk_band IN ('Medium', 'High', 'Critical')")
    needing_review = cursor.fetchone()[0]

    conn.close()
    return {
        "total_events": total_events,
        "band_counts": {
            "Low": band_counts.get("Low", 0),
            "Guarded": band_counts.get("Guarded", 0),
            "Medium": band_counts.get("Medium", 0),
            "High": band_counts.get("High", 0),
            "Critical": band_counts.get("Critical", 0),
        },
        "pending_verifications": pending_verifications,
        "locked_accounts": locked_accounts,
        "needing_review": needing_review,
    }


def seed_demo_data() -> None:
    """Populates realistic synthetic accounts and seed events if the database is newly initialized."""
    init_db()
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("SELECT COUNT(*) FROM accounts")
    if cursor.fetchone()[0] > 0:
        conn.close()
        return

    # Seed Accounts
    accounts_seed = [
        ("ACC-84920", "Jordan Lee", "jordan.lee@synthetic-demo.net", "+1-555-0101", 0, "", ""),
        ("ACC-19342", "Morgan Chen", "morgan.c@synthetic-demo.net", "+1-555-0102", 0, "", ""),
        ("ACC-77215", "Avery Patel", "avery.p@synthetic-demo.net", "+1-555-0103", 0, "", ""),
        ("ACC-30491", "Taylor Brooks", "taylor.b@synthetic-demo.net", "+1-555-0104", 0, "", ""),
        ("ACC-55102", "Samira Khan", "samira.k@synthetic-demo.net", "+1-555-0105", 1, "Critical risk score (95/100) on EVT-INIT-005", "2026-10-15 18:22:10"),
        ("ACC-99231", "Marcus Vance", "marcus.v@synthetic-demo.net", "+1-555-0106", 0, "", ""),
    ]

    now = datetime.now()
    created_str = (now - timedelta(days=30)).strftime("%Y-%m-%d %H:%M:%S")

    for acc in accounts_seed:
        cursor.execute("""
        INSERT INTO accounts (account_id, user_name, email, phone, is_locked, lock_reason, lock_timestamp, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (acc[0], acc[1], acc[2], acc[3], acc[4], acc[5], acc[6], created_str))

    # Seed Historical Events across all risk bands
    seed_events = [
        # Low risk event 1
        (
            "EVT-INIT-001", (now - timedelta(hours=14)).strftime("%Y-%m-%d %H:%M:%S"),
            "ACC-84920", "Login", 0.0, "", "Usual", "Known", "Usual", "Normal", 0, 0, "Usual", "Known",
            "Routine morning login from primary desktop.", 0, 0, "Low",
            json.dumps([]), json.dumps({}),
            "All telemetry baseline verified. Low risk.", "No issue: allow simulated activity and log it.", "ALLOW",
            "ACTIVITY_ALLOWED", "Legitimate", "Verified normal baseline login.",
        ),
        # Low risk event 2
        (
            "EVT-INIT-002", (now - timedelta(hours=11)).strftime("%Y-%m-%d %H:%M:%S"),
            "ACC-99231", "Payment", 45.0, "Utility Co", "Usual", "Known", "Usual", "Normal", 0, 0, "Usual", "Known",
            "Standard monthly electric bill settlement.", 0, 0, "Low",
            json.dumps([]), json.dumps({}),
            "Standard scheduled payment within baseline limits.", "No issue: allow simulated activity and log it.", "ALLOW",
            "ACTIVITY_ALLOWED", "Legitimate", "Normal recurring bill.",
        ),
        # Guarded event 1
        (
            "EVT-INIT-003", (now - timedelta(hours=8)).strftime("%Y-%m-%d %H:%M:%S"),
            "ACC-19342", "Login", 0.0, "", "Different", "Known", "Usual", "Normal", 0, 0, "Unusual", "Known",
            "User accessing portal from international hotel connection.", 30, 30, "Guarded",
            json.dumps(["Different / Unusual Location", "Unusual Activity Time (Off-hours / Anomaly)"]),
            json.dumps({"Different Location": 20, "Unusual Time": 10}),
            "Risk score evaluated at 30/100 [GUARDED RISK]. In-app notification sent.",
            "In-app notification: 'Your account may be at risk. Please review this activity.' Continue monitoring.",
            "NOTIFICATION", "NOTIFICATION_SENT", "Legitimate", "Customer confirmed business travel.",
        ),
        # Medium event 1 (Pending OTP)
        (
            "EVT-INIT-004", (now - timedelta(hours=4)).strftime("%Y-%m-%d %H:%M:%S"),
            "ACC-77215", "Payment", 1250.0, "Global Wire Ext", "Different", "Known", "Unusual", "Frequent", 0, 0, "Usual", "New",
            "Payment from unfamiliar region to a newly added payee.", 60, 60, "Medium",
            json.dumps(["Different / Unusual Location", "Unusual Transaction Amount", "Frequent Transaction Velocity", "New Payment Destination / Untrusted Payee"]),
            json.dumps({"Different Location": 20, "Unusual Amount": 15, "Frequent Transactions": 15, "New Destination": 10}),
            "Risk score evaluated at 60/100 [MEDIUM RISK]. Triggered OTP challenge.",
            "Start simulated OTP verification. Limit attempts. On success, record verification and reassess.",
            "OTP_VERIFICATION", "PENDING_OTP", "Unresolved", "",
        ),
        # High event 1 (Pending Call)
        (
            "EVT-INIT-005", (now - timedelta(hours=2)).strftime("%Y-%m-%d %H:%M:%S"),
            "ACC-30491", "Payment", 3400.0, "Alpha Merchant", "Different", "New", "Unusual", "Normal", 3, 0, "Unusual", "Known",
            "3 prior failed logins followed by new hardware transaction.", 75, 75, "High",
            json.dumps(["Different / Unusual Location", "New / Unfamiliar Device", "Unusual Transaction Amount", "Multiple Failed Logins (3 attempts >= 3 threshold)", "Unusual Activity Time"]),
            json.dumps({"Different Location": 20, "New Device": 10, "Unusual Amount": 15, "Failed Logins (3)": 20, "Unusual Time": 10}),
            "Risk score evaluated at 75/100 [HIGH RISK]. Initiating phone verification.",
            "Start simulated call verification. Provide demo success/failure controls. Record outcome and reassess.",
            "CALL_VERIFICATION", "PENDING_CALL", "Unresolved", "",
        ),
        # Critical event 1 (Blocked & Account Locked)
        (
            "EVT-INIT-006", (now - timedelta(minutes=45)).strftime("%Y-%m-%d %H:%M:%S"),
            "ACC-55102", "Payment", 8900.0, "Crypto Bridge 9", "Different", "New", "Unusual", "Frequent", 4, 3, "Unusual", "New",
            "Severe brute force credentials and PIN violation with payee drain attempt.", 100, 120, "Critical",
            json.dumps(["Different / Unusual Location", "New / Unfamiliar Device", "Unusual Transaction Amount", "Frequent Transaction Velocity", "Multiple Failed Logins", "Too Many Incorrect PIN Attempts", "Unusual Activity Time", "New Payment Destination"]),
            json.dumps({"Different Location": 20, "New Device": 10, "Unusual Amount": 15, "Frequent Transactions": 15, "Failed Logins (4)": 20, "Incorrect PINs (3)": 20, "Unusual Time": 10, "New Destination": 10}),
            "Risk score evaluated at 100/100 [CRITICAL RISK]. Circuit breaker engaged.",
            "Temporarily block the attempted action and lock the synthetic demo account/session.",
            "TEMPORARY_BLOCK", "BLOCKED", "Confirmed Fraud", "Malicious credential brute force attack identified.",
        ),
    ]

    for ev in seed_events:
        cursor.execute("""
        INSERT INTO events (
            event_id, timestamp, account_id, event_type, amount, payment_destination,
            location_status, device_status, amount_pattern, frequency_status,
            failed_logins, incorrect_pins, time_status, destination_status,
            notes, risk_score, raw_score, risk_band, triggered_signals,
            point_contributions, explanation, recommended_action, action_code,
            verification_status, resolution_outcome, analyst_notes, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (ev[0], ev[1], ev[2], ev[3], ev[4], ev[5], ev[6], ev[7], ev[8], ev[9], ev[10], ev[11], ev[12], ev[13], ev[14], ev[15], ev[16], ev[17], ev[18], ev[19], ev[20], ev[21], ev[22], ev[23], ev[24], ev[25], ev[1]))

    # Seed Initial Audit Entries
    audit_seeds = [
        ("EVENT_SUBMITTED", "System initialization: seeded historical baseline telemetry.", "System Bootstrap", "EVT-INIT-001", "ACC-84920"),
        ("NOTIFICATION_SENT", "In-app travel warning pushed to client inbox.", "System Automated", "EVT-INIT-003", "ACC-19342"),
        ("OTP_CHALLENGE_ISSUED", "Demo OTP challenge dispatched (Code: 123456).", "System Automated", "EVT-INIT-004", "ACC-77215"),
        ("CALL_DISPATCHED", "Simulated phone verification call initiated.", "System Automated", "EVT-INIT-005", "ACC-30491"),
        ("ACCOUNT_LOCKED", "Demo account ACC-55102 locked automatically due to critical risk score 100/100.", "SentinelPay Circuit Breaker", "EVT-INIT-006", "ACC-55102"),
    ]

    for aud in audit_seeds:
        cursor.execute("""
        INSERT INTO audit_logs (timestamp, event_id, account_id, action_type, analyst, details)
        VALUES (?, ?, ?, ?, ?, ?)
        """, ((now - timedelta(hours=1)).strftime("%Y-%m-%d %H:%M:%S"), aud[3], aud[4], aud[0], aud[2], aud[1]))

    conn.commit()
    conn.close()
