"""
SentinelPay AI - Overview SOC Operations Dashboard
Tagline: Trust the User. Verify the Risk.
"""

import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime

from core.ui_components import apply_custom_theme, render_header, render_disclaimer_footer, get_band_badge_html
from core.responses import ALL_BANDS
from data.database import get_dashboard_counts, get_all_events, get_all_accounts, seed_demo_data

# Ensure database is seeded
seed_demo_data()

apply_custom_theme()
render_header()

st.title("Operations SOC Overview")
st.markdown("Real-time telemetry and risk response orchestration across synthetic identity & payment channels.")

# Fetch live counts
counts = get_dashboard_counts()
band_counts = counts["band_counts"]
all_events = get_all_events(limit=50)

# Top Metric Banner
col1, col2, col3, col4, col5, col6 = st.columns(6)

with col1:
    st.markdown(f"""
    <div class="metric-card" style="border-left: 3px solid #38BDF8;">
        <div class="metric-label">Total Events</div>
        <div class="metric-value">{counts["total_events"]}</div>
        <div class="metric-sub">Logged in session</div>
    </div>
    """, unsafe_allow_html=True)

with col2:
    st.markdown(f"""
    <div class="metric-card" style="border-left: 3px solid #10B981;">
        <div class="metric-label">Low Risk (0-29)</div>
        <div class="metric-value" style="color: #34D399;">{band_counts.get("Low", 0)}</div>
        <div class="metric-sub">Auto Allowed</div>
    </div>
    """, unsafe_allow_html=True)

with col3:
    st.markdown(f"""
    <div class="metric-card" style="border-left: 3px solid #3B82F6;">
        <div class="metric-label">Guarded (30-49)</div>
        <div class="metric-value" style="color: #60A5FA;">{band_counts.get("Guarded", 0)}</div>
        <div class="metric-sub">Notice Delivered</div>
    </div>
    """, unsafe_allow_html=True)

with col4:
    st.markdown(f"""
    <div class="metric-card" style="border-left: 3px solid #F59E0B;">
        <div class="metric-label">Medium (50-69)</div>
        <div class="metric-value" style="color: #FBBF24;">{band_counts.get("Medium", 0)}</div>
        <div class="metric-sub">OTP Step-up</div>
    </div>
    """, unsafe_allow_html=True)

with col5:
    st.markdown(f"""
    <div class="metric-card" style="border-left: 3px solid #F97316;">
        <div class="metric-label">High (70-89)</div>
        <div class="metric-value" style="color: #FB923C;">{band_counts.get("High", 0)}</div>
        <div class="metric-sub">Voice Call Verify</div>
    </div>
    """, unsafe_allow_html=True)

with col6:
    st.markdown(f"""
    <div class="metric-card" style="border-left: 3px solid #EF4444;">
        <div class="metric-label">Critical (90-100)</div>
        <div class="metric-value" style="color: #F87171;">{band_counts.get("Critical", 0)}</div>
        <div class="metric-sub">Circuit Lock</div>
    </div>
    """, unsafe_allow_html=True)

st.markdown("<br>", unsafe_allow_html=True)

# Quick Action Bar
c_action1, c_action2, c_action3 = st.columns([2, 2, 2])
with c_action1:
    if st.button("⚡ Simulate New Security Event", use_container_width=True, type="primary"):
        st.switch_page("pages/2_Event_Simulator.py")
with c_action2:
    if st.button(f"🔍 Investigation Queue ({counts['needing_review']} items)", use_container_width=True):
        st.switch_page("pages/7_Investigation.py")
with c_action3:
    if st.button(f"🔒 Blocked Accounts ({counts['locked_accounts']} locked)", use_container_width=True):
        st.switch_page("pages/6_Temporary_Block.py")

st.markdown("<br>", unsafe_allow_html=True)

# Visual Distribution Charts
chart_col1, chart_col2 = st.columns([1, 1])

with chart_col1:
    st.subheader("Risk Band Distribution")
    band_df = pd.DataFrame([
        {"Band": "Low (0-29)", "Count": band_counts.get("Low", 0), "Color": "#10B981"},
        {"Band": "Guarded (30-49)", "Count": band_counts.get("Guarded", 0), "Color": "#3B82F6"},
        {"Band": "Medium (50-69)", "Count": band_counts.get("Medium", 0), "Color": "#F59E0B"},
        {"Band": "High (70-89)", "Count": band_counts.get("High", 0), "Color": "#F97316"},
        {"Band": "Critical (90-100)", "Count": band_counts.get("Critical", 0), "Color": "#EF4444"},
    ])
    
    if band_df["Count"].sum() > 0:
        fig_donut = px.pie(
            band_df,
            names="Band",
            values="Count",
            hole=0.55,
            color="Band",
            color_discrete_map={
                "Low (0-29)": "#10B981",
                "Guarded (30-49)": "#3B82F6",
                "Medium (50-69)": "#F59E0B",
                "High (70-89)": "#F97316",
                "Critical (90-100)": "#EF4444",
            }
        )
        fig_donut.update_layout(
            margin=dict(t=10, b=10, l=10, r=10),
            paper_bgcolor="rgba(0,0,0,0)",
            plot_bgcolor="rgba(0,0,0,0)",
            font=dict(color="#CBD5E1", family="Outfit"),
            showlegend=True,
            legend=dict(orientation="h", yanchor="bottom", y=-0.2, xanchor="center", x=0.5),
            height=280,
        )
        st.plotly_chart(fig_donut, use_container_width=True)
    else:
        st.info("No events logged yet. Use the Simulator to generate events.")

with chart_col2:
    st.subheader("Event Velocity by Channel")
    if all_events:
        types_count = {}
        for ev in all_events:
            t = ev.get("event_type", "Unknown")
            types_count[t] = types_count.get(t, 0) + 1
        
        types_df = pd.DataFrame([{"Channel": k, "Volume": v} for k, v in types_count.items()])
        fig_bar = px.bar(
            types_df,
            x="Channel",
            y="Volume",
            color="Channel",
            color_discrete_sequence=["#38BDF8", "#818CF8", "#C084FC"],
        )
        fig_bar.update_layout(
            margin=dict(t=10, b=10, l=10, r=10),
            paper_bgcolor="rgba(0,0,0,0)",
            plot_bgcolor="rgba(0,0,0,0)",
            font=dict(color="#CBD5E1", family="Outfit"),
            xaxis=dict(showgrid=False),
            yaxis=dict(showgrid=True, gridcolor="rgba(255,255,255,0.08)"),
            showlegend=False,
            height=280,
        )
        st.plotly_chart(fig_bar, use_container_width=True)
    else:
        st.info("Awaiting telemetry data.")

# Recent Security Events Table
st.subheader("Recent Evaluated Security Events")

if all_events:
    table_data = []
    for ev in all_events[:8]:
        table_data.append({
            "Event ID": ev["event_id"],
            "Timestamp": ev["timestamp"],
            "Account": ev["account_id"],
            "Type": ev["event_type"],
            "Amount": f"${ev['amount']:,.2f}" if ev["amount"] > 0 else "—",
            "Score": ev["risk_score"],
            "Band": ev["risk_band"],
            "Status": ev["verification_status"],
            "Resolution": ev["resolution_outcome"],
        })
    df_table = pd.DataFrame(table_data)
    st.dataframe(
        df_table,
        use_container_width=True,
        hide_index=True,
        column_config={
            "Score": st.column_config.ProgressColumn(
                "Risk Score",
                help="Dynamic score calculated by SentinelPay AI",
                format="%d",
                min_value=0,
                max_value=100,
            ),
        }
    )
else:
    st.write("No events recorded yet.")

# Non-Overlapping Risk Bands Policy Reference
with st.expander("📖 SentinelPay AI Risk Response Policy Reference (Non-Overlapping Boundaries)", expanded=False):
    st.markdown("""
    | Score Range | Risk Band | Automated Security Action | Verification Mode |
    | :--- | :--- | :--- | :--- |
    | **0 -- 29** | <span style="color: #10B981; font-weight: bold;">Low</span> | **LOW RISK --- ACTIVITY ALLOWED**: Authorize simulated activity and log to audit trail. | None (Passive) |
    | **30 -- 49** | <span style="color: #3B82F6; font-weight: bold;">Guarded</span> | **IN-APP NOTIFICATION**: *"Your account may be at risk. Please review this activity."* Continue monitoring. | Notification |
    | **50 -- 69** | <span style="color: #F59E0B; font-weight: bold;">Medium</span> | **START SIMULATED OTP VERIFICATION**: Step-up passcode required (Demo: `123456`). Limit attempts. | Simulated OTP |
    | **70 -- 89** | <span style="color: #F97316; font-weight: bold;">High</span> | **START SIMULATED CALL VERIFICATION**: Interactive voice confirmation dispatched. Record outcome. | Simulated Voice Call |
    | **90 -- 100** | <span style="color: #EF4444; font-weight: bold;">Critical</span> | **TEMPORARILY BLOCK ACTION & LOCK ACCOUNT**: Circuit breaker engaged. Restrict demo account. | Circuit Breaker Lock |
    """, unsafe_allow_html=True)

render_disclaimer_footer()
