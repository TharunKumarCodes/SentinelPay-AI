"""
SentinelPay AI - Interactive Event Simulator
Tagline: Trust the User. Verify the Risk.

Provides dynamic, real-time risk scoring as the user adjusts login/payment
telemetry signals. User NEVER types the score. Every change immediately
recalculates the score from scratch, updates the risk band, displays the
point contributions breakdown, and recommends the security policy.
"""

import streamlit as st
import uuid
from datetime import datetime

from core.ui_components import apply_custom_theme, render_header, render_disclaimer_footer, get_band_badge_html
from core.risk_engine import calculate_risk, DEFAULT_WEIGHTS, DEFAULT_THRESHOLDS
from core.scenarios import SCENARIOS, get_scenario_by_id
from data.database import save_event, get_all_accounts, seed_demo_data

seed_demo_data()
apply_custom_theme()
render_header()

st.title("⚡ Interactive Event Simulator")
st.markdown(
    "Configure simulated session telemetry below. The risk score recalculates **automatically** "
    "and deterministically on every change. User cannot type the score."
)

# Fetch available demo accounts
demo_accounts = get_all_accounts()
account_options = [acc["account_id"] for acc in demo_accounts] or ["ACC-84920", "ACC-19342", "ACC-77215"]

# Handle scenario preset loading
if "preset_selected" not in st.session_state:
    st.session_state.preset_selected = None

# One-Click Scenario Presets
st.markdown("### 🎯 One-Click Test Scenarios")
sc_cols = st.columns(len(SCENARIOS))

for idx, sc in enumerate(SCENARIOS):
    with sc_cols[idx]:
        if st.button(
            f"**{sc['target_band']}**\n\n{sc['name'].split('.')[1].strip().split('(')[0]}",
            key=f"sc_btn_{sc['id']}",
            use_container_width=True,
            help=sc["description"],
        ):
            st.session_state.preset_selected = sc["id"]
            for k, v in sc["params"].items():
                st.session_state[f"sim_{k}"] = v
            st.rerun()

# Default values initialization in session state
defaults = {
    "sim_event_type": "Login",
    "sim_account_id": account_options[0],
    "sim_location": "Usual",
    "sim_device": "Known",
    "sim_amount_pattern": "Usual",
    "sim_frequency": "Normal",
    "sim_failed_logins": 0,
    "sim_incorrect_pins": 0,
    "sim_time_context": "Usual",
    "sim_payment_destination": "Known",
    "sim_amount": 0.0,
    "sim_notes": "Routine user event",
}

for k, v in defaults.items():
    if k not in st.session_state:
        st.session_state[k] = v

st.markdown("<hr style='border: none; border-top: 1px solid rgba(255,255,255,0.08); margin: 16px 0;'>", unsafe_allow_html=True)

# Layout: Form on Left (60%), Live Reactive Preview on Right (40%)
form_col, preview_col = st.columns([1.1, 0.9], gap="large")

with form_col:
    st.subheader("1. Event Telemetry & Signals")

    row1_c1, row1_c2 = st.columns(2)
    with row1_c1:
        event_type = st.selectbox(
            "Event Type",
            ["Login", "Payment", "PIN attempt"],
            key="sim_event_type",
            help="Transaction or authentication context",
        )
    with row1_c2:
        account_id = st.selectbox(
            "Synthetic Account ID",
            account_options,
            key="sim_account_id",
            help="Synthetic customer account undergoing evaluation",
        )

    st.markdown("#### Geographic & Hardware Baseline")
    row2_c1, row2_c2 = st.columns(2)
    with row2_c1:
        location = st.radio(
            "Geolocation Context",
            ["Usual", "Different"],
            key="sim_location",
            horizontal=True,
            help="Different location triggers +20 risk points",
        )
    with row2_c2:
        device = st.radio(
            "Hardware / Device",
            ["Known", "New"],
            key="sim_device",
            horizontal=True,
            help="New / unfamiliar hardware triggers +10 risk points",
        )

    st.markdown("#### Transaction & Velocity Dynamics")
    row3_c1, row3_c2 = st.columns(2)
    with row3_c1:
        amount_pattern = st.radio(
            "Transaction Amount Pattern",
            ["Usual", "Unusual"],
            key="sim_amount_pattern",
            horizontal=True,
            help="Unusual monetary amount triggers +15 risk points",
        )
    with row3_c2:
        frequency = st.radio(
            "Transaction Velocity / Frequency",
            ["Normal", "Frequent"],
            key="sim_frequency",
            horizontal=True,
            help="High velocity / burst attempts trigger +15 risk points",
        )

    # Optional amount value if payment
    if event_type == "Payment":
        amount_val = st.number_input(
            "Simulated Payment Amount ($)",
            min_value=0.0,
            max_value=250000.0,
            step=50.0,
            key="sim_amount",
            help="Payments >= $5,000 automatically flag unusual amount pattern if not already selected",
        )
    else:
        amount_val = 0.0

    st.markdown("#### Authentication Failures & Security Anomalies")
    row4_c1, row4_c2 = st.columns(2)
    with row4_c1:
        failed_logins = st.slider(
            "Failed Login Attempts (Count)",
            min_value=0,
            max_value=10,
            key="sim_failed_logins",
            help=f"Threshold >= {DEFAULT_THRESHOLDS['failed_logins']} attempts triggers +20 risk points",
        )
    with row4_c2:
        incorrect_pins = st.slider(
            "Incorrect PIN Attempts (Count)",
            min_value=0,
            max_value=10,
            key="sim_incorrect_pins",
            help=f"Threshold >= {DEFAULT_THRESHOLDS['incorrect_pins']} attempts triggers +20 risk points",
        )

    row5_c1, row5_c2 = st.columns(2)
    with row5_c1:
        time_context = st.radio(
            "Time Context",
            ["Usual", "Unusual"],
            key="sim_time_context",
            horizontal=True,
            help="Unusual time / nocturnal off-hours triggers +10 risk points",
        )
    with row5_c2:
        payment_destination = st.radio(
            "Payment Destination / Payee",
            ["Known", "New"],
            key="sim_payment_destination",
            horizontal=True,
            help="New / unregistered beneficiary triggers +10 risk points",
        )

    notes = st.text_input(
        "Analyst Notes / Context",
        key="sim_notes",
        placeholder="e.g. Telemetry captured from residential mobile IP",
    )

# Perform REAL-TIME Dynamic Risk Scoring
# Must evaluate immediately without user typing score
evaluation = calculate_risk(
    event_type=event_type,
    location=location,
    device=device,
    amount_pattern=amount_pattern,
    frequency=frequency,
    failed_logins=failed_logins,
    incorrect_pins=incorrect_pins,
    time_context=time_context,
    payment_destination=payment_destination,
    amount=amount_val,
)

with preview_col:
    st.subheader("2. Real-Time Dynamic Risk Preview")

    # Score Box
    band_color = evaluation.color
    st.markdown(f"""
    <div class="risk-preview-box" style="border-top: 4px solid {band_color};">
        <div style="display: flex; justify-content: space-between; align-items: center;">
            <span style="font-size: 0.85rem; color: #94A3B8; text-transform: uppercase; font-weight: 700; letter-spacing: 0.05em;">Calculated Risk Score</span>
            {get_band_badge_html(evaluation.band, evaluation.score)}
        </div>
        <div style="display: flex; align-items: baseline; gap: 8px; margin: 12px 0;">
            <div class="risk-score-display" style="color: {band_color};">{evaluation.score}</div>
            <div style="font-size: 1.2rem; color: #64748B; font-weight: 600;">/ 100</div>
        </div>
        <div style="background: rgba(255,255,255,0.06); border-radius: 9999px; height: 8px; width: 100%; overflow: hidden; margin-bottom: 12px;">
            <div style="background: {band_color}; height: 100%; width: {evaluation.score}%; transition: width 0.3s ease;"></div>
        </div>
        <div style="font-size: 0.82rem; color: #E2E8F0; line-height: 1.45; margin-bottom: 14px;">
            <strong>Policy Action:</strong> {evaluation.action_title}<br>
            <span style="color: #94A3B8;">{evaluation.recommended_action}</span>
        </div>
    </div>
    """, unsafe_allow_html=True)

    st.markdown("<br>", unsafe_allow_html=True)
    st.markdown("#### Granular Signal Point Attribution")

    if evaluation.point_contributions:
        for sig_name, pts in evaluation.point_contributions.items():
            st.markdown(f"""
            <div class="signal-tag">
                <span>⚠️ {sig_name}</span>
                <span class="signal-points">+{pts} pts</span>
            </div>
            """, unsafe_allow_html=True)
        st.markdown(f"""
        <div style="display: flex; justify-content: space-between; padding: 6px 12px; font-size: 0.85rem; font-weight: 700; color: #CBD5E1;">
            <span>Raw Computed Total:</span>
            <span class="mono">{evaluation.raw_score} pts {f'(capped at 100)' if evaluation.raw_score > 100 else ''}</span>
        </div>
        """, unsafe_allow_html=True)
    else:
        st.markdown("""
        <div style="background: rgba(16, 185, 129, 0.1); border: 1px dashed rgba(16, 185, 129, 0.3); border-radius: 8px; padding: 14px; text-align: center; color: #34D399; font-size: 0.85rem;">
            ✅ Baseline Verified: Zero suspicious signals detected (+0 pts).
        </div>
        """, unsafe_allow_html=True)

    st.markdown("<br>", unsafe_allow_html=True)
    st.markdown("#### Automated Explanation")
    st.info(evaluation.explanation)

    st.markdown("<br>", unsafe_allow_html=True)

    # Submission and Workflow Trigger
    submit_label = f"🚀 Analyze & Submit Event ({evaluation.band} Risk - {evaluation.action_code})"
    if st.button(submit_label, type="primary", use_container_width=True):
        new_event_id = f"EVT-{datetime.now().strftime('%Y%m%d')}-{uuid.uuid4().hex[:6].upper()}"
        
        saved_id = save_event(
            event_id=new_event_id,
            account_id=account_id,
            event_type=event_type,
            amount=amount_val,
            payment_destination="Simulated Payee" if payment_destination == "New" else "Known Merchant",
            location_status=location,
            device_status=device,
            amount_pattern=amount_pattern,
            frequency_status=frequency,
            failed_logins=failed_logins,
            incorrect_pins=incorrect_pins,
            time_status=time_context,
            destination_status=payment_destination,
            notes=notes,
            risk_score=evaluation.score,
            raw_score=evaluation.raw_score,
            risk_band=evaluation.band,
            triggered_signals=evaluation.triggered_signals,
            point_contributions=evaluation.point_contributions,
            explanation=evaluation.explanation,
            recommended_action=evaluation.recommended_action,
            action_code=evaluation.action_code,
            analyst_name=st.session_state.analyst_name,
        )

        st.session_state.active_event_id = saved_id

        # Direct response routing based on non-overlapping boundaries:
        if evaluation.action_code == "ALLOW":
            st.success(f"✅ LOW RISK --- ACTIVITY ALLOWED! Event `{saved_id}` committed to audit log.")
        elif evaluation.action_code == "NOTIFICATION":
            st.warning(f"⚠️ Guarded Risk Notice: In-app warning issued to `{account_id}`. Activity permitted under continuous monitoring.")
        elif evaluation.action_code == "OTP_VERIFICATION":
            st.info(f"📱 Step-up required! Redirecting to OTP Verification console for Event `{saved_id}`...")
            st.switch_page("pages/4_OTP_Verification.py")
        elif evaluation.action_code == "CALL_VERIFICATION":
            st.warning(f"📞 Voice confirmation dispatched! Redirecting to Call Verification for Event `{saved_id}`...")
            st.switch_page("pages/5_Call_Verification.py")
        elif evaluation.action_code == "TEMPORARY_BLOCK":
            st.error(f"🚫 Critical Risk! Action blocked and Account `{account_id}` locked! Redirecting to Temporary Block console...")
            st.switch_page("pages/6_Temporary_Block.py")

render_disclaimer_footer()
