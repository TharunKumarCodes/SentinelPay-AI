"""
SentinelPay AI - Risk Analysis & Telemetry Dossier
Tagline: Trust the User. Verify the Risk.

Provides deep forensic inspection for any synthetic security event:
timestamps, score breakdown, signal attribution, policy triggers,
verification lifecycle, and complete audit trail.
"""

import streamlit as st
import pandas as pd
from datetime import datetime

from core.ui_components import apply_custom_theme, render_header, render_disclaimer_footer, get_band_badge_html
from data.database import get_all_events, get_event_by_id, get_audit_logs, seed_demo_data

seed_demo_data()
apply_custom_theme()
render_header()

st.title("🔬 Deep Risk Analysis & Telemetry")
st.markdown("Forensic telemetry inspection, signal attribution, and security timeline audit.")

# Fetch all events
events = get_all_events(limit=100)
if not events:
    st.warning("No security events available for inspection. Please run the Event Simulator.")
    st.stop()

# Event Selector
event_ids = [e["event_id"] for e in events]
selected_id = st.session_state.get("active_event_id")
default_idx = event_ids.index(selected_id) if selected_id in event_ids else 0

col_sel, col_quick = st.columns([3, 1])
with col_sel:
    active_id = st.selectbox(
        "Select Event ID to Inspect",
        event_ids,
        index=default_idx,
        format_func=lambda x: f"{x} - [{next((e['risk_band'] for e in events if e['event_id'] == x), '')}] - Score: {next((e['risk_score'] for e in events if e['event_id'] == x), '')}",
    )
    st.session_state.active_event_id = active_id

with col_quick:
    st.markdown("<div style='height: 28px;'></div>", unsafe_allow_html=True)
    if st.button("⚡ Simulate Another Event", use_container_width=True):
        st.switch_page("pages/2_Event_Simulator.py")

ev = get_event_by_id(active_id)
if not ev:
    st.error(f"Event {active_id} not found.")
    st.stop()

st.markdown("<hr style='border: none; border-top: 1px solid rgba(255,255,255,0.08); margin: 16px 0;'>", unsafe_allow_html=True)

# Main Dossier Layout
top_c1, top_c2, top_c3, top_c4 = st.columns(4)
with top_c1:
    st.markdown(f"""
    <div class="metric-card">
        <div class="metric-label">Account ID</div>
        <div class="metric-value" style="font-size: 1.4rem;">{ev['account_id']}</div>
        <div class="metric-sub">Channel: {ev['event_type']}</div>
    </div>
    """, unsafe_allow_html=True)

with top_c2:
    st.markdown(f"""
    <div class="metric-card">
        <div class="metric-label">Risk Evaluation</div>
        <div class="metric-value" style="font-size: 1.4rem;">{ev['risk_score']}/100</div>
        <div class="metric-sub">{get_band_badge_html(ev['risk_band'])}</div>
    </div>
    """, unsafe_allow_html=True)

with top_c3:
    st.markdown(f"""
    <div class="metric-card">
        <div class="metric-label">Verification Status</div>
        <div class="metric-value" style="font-size: 1.3rem; color: #38BDF8;">{ev['verification_status']}</div>
        <div class="metric-sub">Updated: {ev['updated_at'].split(' ')[1]}</div>
    </div>
    """, unsafe_allow_html=True)

with top_c4:
    res_color = "#10B981" if ev["resolution_outcome"] == "Legitimate" else ("#EF4444" if ev["resolution_outcome"] == "Confirmed Fraud" else "#94A3B8")
    st.markdown(f"""
    <div class="metric-card">
        <div class="metric-label">Analyst Resolution</div>
        <div class="metric-value" style="font-size: 1.3rem; color: {res_color};">{ev['resolution_outcome']}</div>
        <div class="metric-sub">SOC Review State</div>
    </div>
    """, unsafe_allow_html=True)

st.markdown("<br>", unsafe_allow_html=True)

# Granular Signals & Forensic Timeline
sig_col, timeline_col = st.columns([1.1, 0.9], gap="large")

with sig_col:
    st.subheader("Signal Breakdown & Forensic Attribution")
    st.markdown(f"**Policy Action:** `{ev['action_code']}` — {ev['recommended_action']}")
    
    point_contribs = ev.get("point_contributions", {})
    if point_contribs:
        for sig, pts in point_contribs.items():
            st.markdown(f"""
            <div class="signal-tag">
                <span>🔎 {sig}</span>
                <span class="signal-points">+{pts} pts</span>
            </div>
            """, unsafe_allow_html=True)
    else:
        st.success("Zero anomalies detected. Baseline clean.")

    st.markdown("#### Explainable Rationale")
    st.info(ev["explanation"])

    if ev.get("notes"):
        st.markdown(f"**Event Notes:** `{ev['notes']}`")

    # Workflow action shortcuts
    st.markdown("#### Workflow Navigation")
    w_col1, w_col2 = st.columns(2)
    with w_col1:
        if ev["verification_status"] == "PENDING_OTP":
            if st.button("📱 Open OTP Verification Flow", type="primary", use_container_width=True):
                st.switch_page("pages/4_OTP_Verification.py")
        elif ev["verification_status"] == "PENDING_CALL":
            if st.button("📞 Open Call Verification Flow", type="primary", use_container_width=True):
                st.switch_page("pages/5_Call_Verification.py")
        elif ev["verification_status"] == "BLOCKED":
            if st.button("🚫 Open Temporary Block Console", type="primary", use_container_width=True):
                st.switch_page("pages/6_Temporary_Block.py")
        else:
            st.button("✅ Workflow Already Finalized", disabled=True, use_container_width=True)
    
    with w_col2:
        if st.button("🕵️ Open Investigation Dossier", use_container_width=True):
            st.switch_page("pages/7_Investigation.py")

with timeline_col:
    st.subheader("Event Lifecycle Timeline")
    
    # Render interactive progression steps
    st.markdown(f"""
    <div style="border-left: 2px solid #38BDF8; padding-left: 18px; margin-left: 8px;">
        <div style="margin-bottom: 20px;">
            <div style="font-weight: 700; color: #38BDF8; font-size: 0.9rem;">1. EVENT INGESTION</div>
            <div style="font-size: 0.78rem; color: #94A3B8;">{ev['timestamp']}</div>
            <div style="font-size: 0.85rem; color: #CBD5E1; margin-top: 2px;">
                Channel: <strong>{ev['event_type']}</strong> for Account <strong>{ev['account_id']}</strong>.
                {f"Amount: ${ev['amount']:,.2f}" if ev['amount'] > 0 else ""}
            </div>
        </div>
        <div style="margin-bottom: 20px;">
            <div style="font-weight: 700; color: #818CF8; font-size: 0.9rem;">2. RISK SCORING ENGINE</div>
            <div style="font-size: 0.85rem; color: #CBD5E1; margin-top: 2px;">
                Evaluated score: <strong>{ev['risk_score']}/100</strong> ({ev['risk_band']}).
                Computed {len(ev.get('triggered_signals', []))} risk triggers.
            </div>
        </div>
        <div style="margin-bottom: 20px;">
            <div style="font-weight: 700; color: #F59E0B; font-size: 0.9rem;">3. AUTOMATED POLICY TRIGGER</div>
            <div style="font-size: 0.85rem; color: #CBD5E1; margin-top: 2px;">
                Action: <strong>{ev['action_code']}</strong>.
                Status set to: <strong>{ev['verification_status']}</strong>.
            </div>
        </div>
        <div style="margin-bottom: 20px;">
            <div style="font-weight: 700; color: #34D399; font-size: 0.9rem;">4. VERIFICATION / AUDIT STATE</div>
            <div style="font-size: 0.85rem; color: #CBD5E1; margin-top: 2px;">
                Current status: <strong>{ev['verification_status']}</strong>.
            </div>
        </div>
        <div>
            <div style="font-weight: 700; color: {res_color}; font-size: 0.9rem;">5. SOC INVESTIGATION RESOLUTION</div>
            <div style="font-size: 0.85rem; color: #CBD5E1; margin-top: 2px;">
                Outcome: <strong>{ev['resolution_outcome']}</strong>.
                {f"<br>Notes: <em>{ev['analyst_notes']}</em>" if ev['analyst_notes'] else ""}
            </div>
        </div>
    </div>
    """, unsafe_allow_html=True)

# Event Audit Logs
st.markdown("<br>", unsafe_allow_html=True)
st.subheader("Event-Specific Audit Trail")
logs = get_audit_logs(event_id=active_id)
if logs:
    log_df = pd.DataFrame([
        {
            "Timestamp": l["timestamp"],
            "Action": l["action_type"],
            "Analyst / System": l["analyst"],
            "Details": l["details"],
        }
        for l in logs
    ])
    st.dataframe(log_df, use_container_width=True, hide_index=True)
else:
    st.caption("No explicit audit log entries for this event.")

render_disclaimer_footer()
