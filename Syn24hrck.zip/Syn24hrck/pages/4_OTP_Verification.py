"""
SentinelPay AI - Simulated OTP Verification Console
Tagline: Trust the User. Verify the Risk.

Demonstrates simulated step-up authentication for Medium risk events (50-69).
Uses synthetic demo passcode (123456). Enforces attempt limit.
Never resets score to zero. Records immutable audit trail.
"""

import streamlit as st
from datetime import datetime

from core.ui_components import apply_custom_theme, render_header, render_disclaimer_footer, get_band_badge_html
from core.verification import DEMO_OTP_CODE, MAX_OTP_ATTEMPTS, verify_otp_attempt
from data.database import (
    get_all_events,
    get_event_by_id,
    update_event_verification,
    add_audit_log,
    seed_demo_data,
)

seed_demo_data()
apply_custom_theme()
render_header()

st.title("📱 Simulated Step-Up OTP Verification")
st.markdown("Interactive multi-factor passcode verification for events evaluated in the **Medium Risk Band (50-69)**.")

# Identify candidate events
all_events = get_all_events(limit=50)
otp_candidates = [
    e for e in all_events
    if e["verification_status"] == "PENDING_OTP" or e["risk_band"] == "Medium"
]

if not otp_candidates:
    otp_candidates = all_events[:5]

candidate_ids = [e["event_id"] for e in otp_candidates]
current_active = st.session_state.get("active_event_id")
default_idx = candidate_ids.index(current_active) if current_active in candidate_ids else 0

active_id = st.selectbox(
    "Select Event for Step-Up Verification",
    candidate_ids,
    index=default_idx,
    format_func=lambda x: f"{x} - [{next((e['risk_band'] for e in otp_candidates if e['event_id'] == x), '')}] Status: {next((e['verification_status'] for e in otp_candidates if e['event_id'] == x), '')}",
)
st.session_state.active_event_id = active_id
ev = get_event_by_id(active_id)

if not ev:
    st.error("Event not found.")
    st.stop()

# Track attempts in session state per event
attempt_key = f"otp_attempts_{active_id}"
if attempt_key not in st.session_state:
    st.session_state[attempt_key] = 0

attempts_used = st.session_state[attempt_key]
attempts_left = max(0, MAX_OTP_ATTEMPTS - attempts_used)

st.markdown("<hr style='border: none; border-top: 1px solid rgba(255,255,255,0.08); margin: 16px 0;'>", unsafe_allow_html=True)

# Layout
col_info, col_auth = st.columns([1, 1], gap="large")

with col_info:
    st.subheader("Event Summary Under Challenge")
    st.markdown(f"""
    <div class="metric-card" style="margin-bottom: 16px;">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
            <span style="font-weight: 700; color: #38BDF8;">{ev['event_id']}</span>
            {get_band_badge_html(ev['risk_band'], ev['risk_score'])}
        </div>
        <div style="font-size: 0.85rem; color: #CBD5E1;">
            <strong>Account:</strong> <code>{ev['account_id']}</code><br>
            <strong>Type:</strong> {ev['event_type']} {f"(${ev['amount']:,.2f})" if ev['amount'] > 0 else ""}<br>
            <strong>Current Status:</strong> <span style="color: #FBBF24; font-weight: 600;">{ev['verification_status']}</span><br>
            <strong>Original Score:</strong> {ev['risk_score']}/100 (Preserved across challenge)
        </div>
    </div>
    """, unsafe_allow_html=True)

    st.markdown("#### Signals That Triggered Step-Up")
    for sig, pts in ev.get("point_contributions", {}).items():
        st.markdown(f"""
        <div class="signal-tag">
            <span>⚠️ {sig}</span>
            <span class="signal-points">+{pts} pts</span>
        </div>
        """, unsafe_allow_html=True)

with col_auth:
    st.subheader("Simulated Authenticator Challenge")

    # Visible Demo Test Code Banner
    st.markdown(f"""
    <div style="background: rgba(245, 158, 11, 0.12); border: 1px dashed #F59E0B; border-radius: 8px; padding: 12px 16px; margin-bottom: 18px;">
        <div style="font-size: 0.78rem; text-transform: uppercase; font-weight: 700; color: #FBBF24; letter-spacing: 0.05em;">🧪 Synthetic Test Credentials</div>
        <div style="font-size: 1.15rem; font-weight: 800; color: #FDE68A; margin: 4px 0;">
            Demo Passcode: <span class="mono" style="letter-spacing: 0.15em;">{DEMO_OTP_CODE}</span>
        </div>
        <div style="font-size: 0.75rem; color: #94A3B8;">
            Synthetic simulation only. No cellular or SMS carrier traffic is transmitted.
        </div>
    </div>
    """, unsafe_allow_html=True)

    # Check if already verified
    if ev["verification_status"] == "OTP_VERIFIED":
        st.success("✅ Step-Up Passed! This event has already been successfully verified via OTP.")
        st.markdown(f"**Outcome:** Verified identity. Original risk score `{ev['risk_score']}/100` preserved in audit trail.")
        if st.button("🔬 View Forensic Analysis", use_container_width=True):
            st.switch_page("pages/3_Risk_Analysis.py")
    elif ev["verification_status"] == "OTP_FAILED":
        st.error("❌ Verification Failed! Max attempts were exceeded for this event. Escalated to SOC investigation.")
        if st.button("🕵️ Open in Investigation Center", use_container_width=True):
            st.switch_page("pages/7_Investigation.py")
    else:
        st.markdown(f"**Verification Attempts:** `{attempts_used}/{MAX_OTP_ATTEMPTS}` (Remaining: `{attempts_left}`)")

        otp_input = st.text_input(
            "Enter 6-Digit Passcode",
            max_chars=6,
            placeholder="Enter code (or use 123456)",
            help=f"Type '{DEMO_OTP_CODE}' to simulate authorized user response",
            key=f"input_code_{active_id}",
        )

        c_sub1, c_sub2 = st.columns(2)
        with c_sub1:
            if st.button("🔓 Verify Passcode", type="primary", use_container_width=True, disabled=(attempts_left <= 0)):
                if not otp_input:
                    st.warning("Please type a passcode or click the demo code above.")
                else:
                    res = verify_otp_attempt(otp_input, attempts_used)
                    st.session_state[attempt_key] = res.attempts_used

                    if res.success:
                        # Update event status, keep score intact!
                        update_event_verification(
                            event_id=active_id,
                            new_verification_status="OTP_VERIFIED",
                            analyst_name=st.session_state.analyst_name,
                            audit_notes=f"Synthetic OTP successfully validated with code '{otp_input}'. Score remains {ev['risk_score']}.",
                            is_success=True,
                        )
                        st.success("🎉 Passcode Verified! Activity permitted under verified step-up credentials.")
                        st.balloons()
                        st.rerun()
                    else:
                        if res.is_exhausted:
                            update_event_verification(
                                event_id=active_id,
                                new_verification_status="OTP_FAILED",
                                analyst_name=st.session_state.analyst_name,
                                audit_notes=f"OTP verification attempts exhausted ({res.attempts_used}/{MAX_OTP_ATTEMPTS}). Escalating to fraud review.",
                                is_success=False,
                            )
                            st.error("🚫 Maximum verification attempts exhausted! Event escalated for investigation.")
                            st.rerun()
                        else:
                            st.error(f"❌ {res.message}")

        with c_sub2:
            if st.button("🚨 Escalate / Abandon", use_container_width=True):
                update_event_verification(
                    event_id=active_id,
                    new_verification_status="PENDING_REVIEW",
                    analyst_name=st.session_state.analyst_name,
                    audit_notes="User abandoned simulated OTP challenge. Flagged for analyst investigation.",
                )
                st.warning("Event flagged as Abandoned. Routed to Investigation Center.")
                st.switch_page("pages/7_Investigation.py")

        st.markdown("<br>", unsafe_allow_html=True)
        if st.button("🔄 Simulate Resend SMS Passcode", use_container_width=True):
            add_audit_log(
                action_type="OTP_RESEND_SIMULATED",
                details=f"Simulated passcode SMS re-dispatched to registered phone for account {ev['account_id']}.",
                analyst="Synthetic Carrier Mock",
                event_id=active_id,
                account_id=ev["account_id"],
            )
            st.info("📲 Simulated OTP re-sent: Code `123456` delivered to simulated device.")

render_disclaimer_footer()
