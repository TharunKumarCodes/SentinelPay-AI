"""
SentinelPay AI - Simulated Voice Call Verification Terminal
Tagline: Trust the User. Verify the Risk.

Demonstrates interactive phone confirmation for High Risk events (70-89).
Simulates IVR interactive voice prompts with demo success, fraud-alert,
and timeout controls without dialing real telephone networks.
"""

import streamlit as st
from datetime import datetime

from core.ui_components import apply_custom_theme, render_header, render_disclaimer_footer, get_band_badge_html
from core.verification import handle_call_simulation_action
from data.database import (
    get_all_events,
    get_event_by_id,
    get_account,
    lock_account,
    update_event_verification,
    add_audit_log,
    seed_demo_data,
)

seed_demo_data()
apply_custom_theme()
render_header()

st.title("📞 Simulated Call Verification Terminal")
st.markdown("Interactive voice verification console for events evaluated in the **High Risk Band (70-89)**.")

# Identify candidate events
all_events = get_all_events(limit=50)
call_candidates = [
    e for e in all_events
    if e["verification_status"] == "PENDING_CALL" or e["risk_band"] == "High"
]

if not call_candidates:
    call_candidates = all_events[:5]

candidate_ids = [e["event_id"] for e in call_candidates]
current_active = st.session_state.get("active_event_id")
default_idx = candidate_ids.index(current_active) if current_active in candidate_ids else 0

active_id = st.selectbox(
    "Select High-Risk Event for Call Verification",
    candidate_ids,
    index=default_idx,
    format_func=lambda x: f"{x} - [{next((e['risk_band'] for e in call_candidates if e['event_id'] == x), '')}] Status: {next((e['verification_status'] for e in call_candidates if e['event_id'] == x), '')}",
)
st.session_state.active_event_id = active_id
ev = get_event_by_id(active_id)

if not ev:
    st.error("Event not found.")
    st.stop()

acc = get_account(ev["account_id"]) or {}
phone_num = acc.get("phone", "+1-555-0199")

# Simulated Call State Key
call_state_key = f"call_state_{active_id}"
if call_state_key not in st.session_state:
    st.session_state[call_state_key] = "WAITING_FOR_CONFIRMATION"

current_call_state = st.session_state[call_state_key]

st.markdown("<hr style='border: none; border-top: 1px solid rgba(255,255,255,0.08); margin: 16px 0;'>", unsafe_allow_html=True)

# Layout: Dossier & Call Terminal
col_dossier, col_phone = st.columns([1, 1], gap="large")

with col_dossier:
    st.subheader("Event Telemetry & Escalation Signals")
    st.markdown(f"""
    <div class="metric-card" style="margin-bottom: 16px; border-left: 4px solid #F97316;">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
            <span style="font-weight: 700; color: #FB923C;">{ev['event_id']}</span>
            {get_band_badge_html(ev['risk_band'], ev['risk_score'])}
        </div>
        <div style="font-size: 0.85rem; color: #CBD5E1;">
            <strong>Target Account:</strong> <code>{ev['account_id']}</code> ({acc.get('user_name', 'Synthetic User')})<br>
            <strong>Registered Telephony:</strong> <span class="mono" style="color: #38BDF8;">{phone_num}</span><br>
            <strong>Channel:</strong> {ev['event_type']} {f"(${ev['amount']:,.2f})" if ev['amount'] > 0 else ""}<br>
            <strong>Score:</strong> {ev['risk_score']}/100 (High Risk Policy Triggered)
        </div>
    </div>
    """, unsafe_allow_html=True)

    st.markdown("#### Signals Breaching High-Risk Threshold")
    for sig, pts in ev.get("point_contributions", {}).items():
        st.markdown(f"""
        <div class="signal-tag" style="border-left-color: #F97316;">
            <span>⚠️ {sig}</span>
            <span class="signal-points" style="color: #FB923C; background: rgba(249, 115, 22, 0.12);">+{pts} pts</span>
        </div>
        """, unsafe_allow_html=True)

    st.markdown("#### Explainable Rationale")
    st.info(ev["explanation"])

with col_phone:
    st.subheader("Simulated IVR Call Dispatcher")

    # Status Pill Colors
    status_display_map = {
        "WAITING_FOR_CONFIRMATION": ("#FBBF24", "rgba(245, 158, 11, 0.15)", "Waiting for Confirmation"),
        "RINGING": ("#60A5FA", "rgba(59, 130, 246, 0.15)", "Simulated Line Ringing..."),
        "VERIFIED": ("#34D399", "rgba(16, 185, 129, 0.15)", "Call Verified by User"),
        "VERIFICATION_FAILED": ("#F87171", "rgba(239, 68, 68, 0.15)", "Verification Failed (Timeout/No Answer)"),
        "FRAUD_REPORTED": ("#EF4444", "rgba(239, 68, 68, 0.25)", "User Reported Fraud on Call!"),
    }
    s_fg, s_bg, s_title = status_display_map.get(
        current_call_state, ("#94A3B8", "rgba(148, 163, 184, 0.15)", current_call_state)
    )

    st.markdown(f"""
    <div style="background: rgba(15, 23, 42, 0.85); border: 1px solid rgba(255,255,255,0.12); border-radius: 14px; padding: 22px; margin-bottom: 20px;">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
            <span style="font-size: 0.8rem; text-transform: uppercase; color: #94A3B8; font-weight: 700; letter-spacing: 0.05em;">Dispatch Status</span>
            <span style="background: {s_bg}; color: {s_fg}; border: 1px solid {s_fg}; font-size: 0.76rem; font-weight: 700; padding: 2px 10px; border-radius: 6px;">
                {s_title}
            </span>
        </div>
        <div style="font-size: 1.3rem; font-weight: 800; color: #F8FAFC; margin-bottom: 4px;">
            Simulated Call to <span class="mono" style="color: #38BDF8;">{phone_num}</span>
        </div>
        <div style="font-size: 0.82rem; color: #94A3B8; line-height: 1.45;">
            "Hello, this is SentinelPay AI automated fraud protection. Did you attempt a {ev['event_type']} transaction of {f'${ev['amount']:,.2f}' if ev['amount'] > 0 else 'activity'}?"
        </div>
    </div>
    """, unsafe_allow_html=True)

    st.markdown("#### Interactive Simulated User Controls")
    st.caption("Use these demo controls to simulate realistic customer voice responses:")

    btn_c1, btn_c2 = st.columns(2)
    with btn_c1:
        if st.button("✅ Simulate Press [1]: Confirm & Authorize", type="primary", use_container_width=True):
            res = handle_call_simulation_action("CONFIRM")
            st.session_state[call_state_key] = res.status
            update_event_verification(
                event_id=active_id,
                new_verification_status="CALL_VERIFIED",
                analyst_name=st.session_state.analyst_name,
                audit_notes=res.message,
                is_success=True,
            )
            st.success(f"🎉 {res.title}! {res.message}")
            st.balloons()
            st.rerun()

    with btn_c2:
        if st.button("🚨 Simulate Press [2]: Report Unauthorized Fraud", use_container_width=True):
            res = handle_call_simulation_action("REPORT_FRAUD")
            st.session_state[call_state_key] = res.status
            update_event_verification(
                event_id=active_id,
                new_verification_status="CALL_FAILED",
                analyst_name=st.session_state.analyst_name,
                audit_notes=res.message,
                is_success=False,
            )
            # Lock the account immediately upon customer fraud report
            lock_account(
                account_id=ev["account_id"],
                reason=f"Account holder flagged fraud on simulated verification call for event {active_id}.",
                analyst_name="Automated Call Dispatcher",
            )
            st.error(f"🛑 {res.title}! Account locked and escalated to fraud queue.")
            st.rerun()

    st.markdown("<br>", unsafe_allow_html=True)
    row_sub_c1, row_sub_c2 = st.columns(2)
    with row_sub_c1:
        if st.button("⏳ Simulate: Call Timed Out / No Answer", use_container_width=True):
            res = handle_call_simulation_action("TIMEOUT")
            st.session_state[call_state_key] = res.status
            update_event_verification(
                event_id=active_id,
                new_verification_status="CALL_FAILED",
                analyst_name=st.session_state.analyst_name,
                audit_notes=res.message,
                is_success=False,
            )
            st.warning(f"⚠️ {res.title}: Event kept pending for human analyst investigation.")
            st.rerun()

    with row_sub_c2:
        if st.button("🔄 Reset / Re-dispatch Call", use_container_width=True):
            st.session_state[call_state_key] = "WAITING_FOR_CONFIRMATION"
            add_audit_log(
                action_type="CALL_REDISPATCH_SIMULATED",
                details=f"Simulated phone call re-dialed to {phone_num}.",
                analyst=st.session_state.analyst_name,
                event_id=active_id,
                account_id=ev["account_id"],
            )
            st.info("Simulated call state reset to 'Waiting for confirmation'.")
            st.rerun()

render_disclaimer_footer()
