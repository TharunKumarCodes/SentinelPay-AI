"""
SentinelPay AI - Temporary Block & Circuit Breaker Console
Tagline: Trust the User. Verify the Risk.

Demonstrates automated circuit-breaker account lockdown for Critical Risk
events (90-100). Displays critical security dossier, lock status, next steps,
and safe demo unlock / reset controls with full audit logging.
"""

import streamlit as st
from datetime import datetime

from core.ui_components import apply_custom_theme, render_header, render_disclaimer_footer, get_band_badge_html
from data.database import (
    get_all_accounts,
    get_account,
    get_all_events,
    lock_account,
    unlock_account,
    get_audit_logs,
    seed_demo_data,
)

seed_demo_data()
apply_custom_theme()
render_header()

st.title("🚫 Temporary Block & Account Lockdown Console")
st.markdown("Automated containment and emergency circuit breaker for **Critical Risk Events (90-100)**.")

# Fetch all demo accounts
accounts = get_all_accounts()
if not accounts:
    st.error("No accounts loaded.")
    st.stop()

# Account selector
account_ids = [acc["account_id"] for acc in accounts]
locked_ids = [acc["account_id"] for acc in accounts if acc["is_locked"] == 1]

# Prioritize first locked account if available
default_idx = account_ids.index(locked_ids[0]) if locked_ids else 0

active_acc_id = st.selectbox(
    "Select Synthetic Demo Account to Inspect",
    account_ids,
    index=default_idx,
    format_func=lambda x: f"{'🔒 [LOCKED] ' if next((a['is_locked'] for a in accounts if a['account_id'] == x), 0) == 1 else '✅ [ACTIVE] '} {x} - {next((a['user_name'] for a in accounts if a['account_id'] == x), '')}",
)

acc = get_account(active_acc_id)
is_locked = acc.get("is_locked", 0) == 1

st.markdown("<hr style='border: none; border-top: 1px solid rgba(255,255,255,0.08); margin: 16px 0;'>", unsafe_allow_html=True)

# Status Alert Banner
if is_locked:
    st.markdown(f"""
    <div style="background: rgba(239, 68, 68, 0.15); border: 2px solid #EF4444; border-radius: 12px; padding: 20px; margin-bottom: 24px;">
        <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 8px;">
            <span style="font-size: 2rem;">🛑</span>
            <div>
                <div style="font-size: 1.25rem; font-weight: 800; color: #FCA5A5; letter-spacing: -0.02em;">
                    CIRCUIT BREAKER ENGAGED: DEMO ACCOUNT TEMPORARILY LOCKED
                </div>
                <div style="font-size: 0.82rem; color: #E2E8F0;">
                    Lock Reason: <code>{acc.get('lock_reason', 'Critical risk threshold breached')}</code>
                </div>
            </div>
        </div>
        <div style="font-size: 0.8rem; color: #94A3B8; margin-top: 6px;">
            Timestamp: <span class="mono" style="color: #CBD5E1;">{acc.get('lock_timestamp', 'Recent')}</span> | Target: <span class="mono" style="color: #CBD5E1;">{active_acc_id} ({acc.get('user_name', '')})</span>
        </div>
    </div>
    """, unsafe_allow_html=True)
else:
    st.markdown(f"""
    <div style="background: rgba(16, 185, 129, 0.12); border: 1px solid #10B981; border-radius: 12px; padding: 18px; margin-bottom: 24px;">
        <div style="display: flex; align-items: center; gap: 10px;">
            <span style="font-size: 1.6rem;">✅</span>
            <div>
                <div style="font-size: 1.1rem; font-weight: 700; color: #34D399;">DEMO ACCOUNT ACTIVE (NO RESTRICTIONS)</div>
                <div style="font-size: 0.8rem; color: #94A3B8;">Account <code>{active_acc_id}</code> is authorized for standard operations and simulated events.</div>
            </div>
        </div>
    </div>
    """, unsafe_allow_html=True)

# Evidence Dossier & Controls
col_ev, col_unlock = st.columns([1.1, 0.9], gap="large")

with col_ev:
    st.subheader("Security Dossier & Associated Critical Events")

    # Find events for this account
    all_events = get_all_events(limit=100)
    acc_events = [e for e in all_events if e["account_id"] == active_acc_id]

    if acc_events:
        crit_event = next((e for e in acc_events if e["risk_band"] == "Critical"), acc_events[0])
        st.markdown(f"""
        <div class="metric-card" style="margin-bottom: 16px; border-left: 4px solid #EF4444;">
            <div style="display: flex; justify-content: space-between; align-items: center;">
                <span style="font-weight: 700; color: #F87171;">Event {crit_event['event_id']}</span>
                {get_band_badge_html(crit_event['risk_band'], crit_event['risk_score'])}
            </div>
            <div style="font-size: 0.85rem; color: #CBD5E1; margin: 8px 0;">
                <strong>Channel:</strong> {crit_event['event_type']} {f"(${crit_event['amount']:,.2f})" if crit_event['amount'] > 0 else ""}<br>
                <strong>Calculated Score:</strong> {crit_event['risk_score']}/100 [CRITICAL]<br>
                <strong>Recorded Action:</strong> <code>{crit_event['action_code']}</code>
            </div>
            <div style="font-size: 0.8rem; color: #94A3B8;">
                {crit_event['explanation']}
            </div>
        </div>
        """, unsafe_allow_html=True)

        st.markdown("#### Triggered Evidence Signals")
        for sig, pts in crit_event.get("point_contributions", {}).items():
            st.markdown(f"""
            <div class="signal-tag" style="border-left-color: #EF4444;">
                <span>⚠️ {sig}</span>
                <span class="signal-points" style="color: #F87171; background: rgba(239, 68, 68, 0.12);">+{pts} pts</span>
            </div>
            """, unsafe_allow_html=True)
    else:
        st.info("No recorded events for this account.")

    st.markdown("#### Automated Containment Next Steps")
    st.markdown("""
    1. **Session Invalidation:** All synthetic tokens and active sessions terminated.
    2. **Transaction Halt:** Any in-flight payments or transfers immediately blocked.
    3. **Analyst Review Gate:** Account remains locked until authorized SOC analyst review.
    4. **Customer Communication:** Out-of-band notification dispatched advising of security hold.
    """)

with col_unlock:
    st.subheader("Controlled Demo Unlock & Recovery")
    
    if is_locked:
        st.markdown("Analyst authorization is required to unlock this demo account.")
        unlock_reason = st.text_area(
            "Analyst Unlock Justification (Required for Audit Trail)",
            value="Identity re-verified via out-of-band identity check. Customer confirmed legitimate intent.",
            key="unlock_reason_input",
            help="Documented reason recorded in immutable compliance audit logs",
        )

        if st.button("🔓 Authorized Analyst Override & Unlock Account", type="primary", use_container_width=True):
            if not unlock_reason.strip():
                st.error("Please provide an unlock justification for the compliance audit log.")
            else:
                unlock_account(
                    account_id=active_acc_id,
                    reason=unlock_reason.strip(),
                    analyst_name=st.session_state.analyst_name,
                )
                st.success(f"🎉 Demo Account {active_acc_id} restored to ACTIVE status!")
                st.rerun()

        st.markdown("<br>", unsafe_allow_html=True)
        if st.button("🔄 Quick Demo Reset (Clear Lock)", use_container_width=True):
            unlock_account(
                account_id=active_acc_id,
                reason="One-click demo environment reset",
                analyst_name="Demo Environment Reset",
            )
            st.info("Account lock cleared.")
            st.rerun()

    else:
        st.info(f"Account `{active_acc_id}` is not currently locked.")
        manual_lock_reason = st.text_input(
            "Manual Quarantine Reason",
            value="Preemptive security lockdown for suspicious activity testing",
            key="manual_lock_input",
        )
        if st.button("🔒 Manually Quarantine Account (Simulate Circuit Breaker)", type="secondary", use_container_width=True):
            lock_account(
                account_id=active_acc_id,
                reason=manual_lock_reason,
                analyst_name=st.session_state.analyst_name,
            )
            st.warning(f"Account {active_acc_id} locked manually.")
            st.rerun()

# Audit trail for this account
st.markdown("<br>", unsafe_allow_html=True)
st.subheader("Account Lock & Unlock Audit History")
acc_logs = get_audit_logs(account_id=active_acc_id)
if acc_logs:
    st.dataframe(
        [
            {
                "Timestamp": l["timestamp"],
                "Action": l["action_type"],
                "Analyst": l["analyst"],
                "Details": l["details"],
            }
            for l in acc_logs
        ],
        use_container_width=True,
        hide_index=True,
    )
else:
    st.caption("No account-level audit events recorded.")

render_disclaimer_footer()
