"""
SentinelPay AI - SOC Investigation Center
Tagline: Trust the User. Verify the Risk.

Enables SOC analysts and fraud investigators to triage pending/unresolved
events, review evidence dossiers, attach investigative notes, and record
conclusive dispositions (Confirmed Fraud, Legitimate, Unresolved).
"""

import streamlit as st
import pandas as pd
from datetime import datetime

from core.ui_components import apply_custom_theme, render_header, render_disclaimer_footer, get_band_badge_html
from data.database import (
    get_all_events,
    get_event_by_id,
    update_investigation_resolution,
    get_audit_logs,
    seed_demo_data,
)

seed_demo_data()
apply_custom_theme()
render_header()

st.title("🕵️ SOC Fraud Investigation Center")
st.markdown("Investigate suspicious activity, inspect signal forensics, and log formal case dispositions.")

# Fetch all events
events = get_all_events(limit=100)
if not events:
    st.info("No events available in database.")
    st.stop()

# Queue Filters
f_col1, f_col2 = st.columns([1, 1])
with f_col1:
    filter_status = st.selectbox(
        "Queue Filter",
        ["Needs Review (Unresolved)", "All Events", "Confirmed Fraud", "Legitimate"],
        index=0,
    )
with f_col2:
    filter_band = st.selectbox(
        "Risk Band Filter",
        ["All Bands", "Medium, High & Critical", "Critical Only", "High Only", "Medium Only", "Guarded Only", "Low Only"],
        index=1,
    )

# Apply filters
filtered_events = list(events)
if filter_status == "Needs Review (Unresolved)":
    filtered_events = [e for e in filtered_events if e["resolution_outcome"] == "Unresolved"]
elif filter_status == "Confirmed Fraud":
    filtered_events = [e for e in filtered_events if e["resolution_outcome"] == "Confirmed Fraud"]
elif filter_status == "Legitimate":
    filtered_events = [e for e in filtered_events if e["resolution_outcome"] == "Legitimate"]

if filter_band == "Medium, High & Critical":
    filtered_events = [e for e in filtered_events if e["risk_band"] in ("Medium", "High", "Critical")]
elif filter_band == "Critical Only":
    filtered_events = [e for e in filtered_events if e["risk_band"] == "Critical"]
elif filter_band == "High Only":
    filtered_events = [e for e in filtered_events if e["risk_band"] == "High"]
elif filter_band == "Medium Only":
    filtered_events = [e for e in filtered_events if e["risk_band"] == "Medium"]
elif filter_band == "Guarded Only":
    filtered_events = [e for e in filtered_events if e["risk_band"] == "Guarded"]
elif filter_band == "Low Only":
    filtered_events = [e for e in filtered_events if e["risk_band"] == "Low"]

if not filtered_events:
    st.success(f"🎉 No cases matching filter: '{filter_status}' & '{filter_band}'. All queues up to date!")
    filtered_events = events[:5]  # Fallback to show selection

# Case Selector
event_ids = [e["event_id"] for e in filtered_events]
current_active = st.session_state.get("active_event_id")
default_idx = event_ids.index(current_active) if current_active in event_ids else 0

active_id = st.selectbox(
    f"Active Case Dossier ({len(filtered_events)} in queue)",
    event_ids,
    index=default_idx,
    format_func=lambda x: f"{x} - [{next((e['risk_band'] for e in filtered_events if e['event_id'] == x), '')}] Score: {next((e['risk_score'] for e in filtered_events if e['event_id'] == x), '')} - Status: {next((e['verification_status'] for e in filtered_events if e['event_id'] == x), '')}",
)
st.session_state.active_event_id = active_id
ev = get_event_by_id(active_id)

st.markdown("<hr style='border: none; border-top: 1px solid rgba(255,255,255,0.08); margin: 16px 0;'>", unsafe_allow_html=True)

# Layout: Dossier & Disposition Form
dossier_col, disposition_col = st.columns([1.1, 0.9], gap="large")

with dossier_col:
    st.subheader("Case Telemetry & Evidence Dossier")

    st.markdown(f"""
    <div class="metric-card" style="margin-bottom: 16px;">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
            <span style="font-weight: 800; font-size: 1.15rem; color: #38BDF8;">{ev['event_id']}</span>
            {get_band_badge_html(ev['risk_band'], ev['risk_score'])}
        </div>
        <div style="font-size: 0.85rem; color: #CBD5E1; line-height: 1.6;">
            <strong>Target Account:</strong> <code>{ev['account_id']}</code><br>
            <strong>Timestamp:</strong> {ev['timestamp']}<br>
            <strong>Channel / Type:</strong> {ev['event_type']} {f"(${ev['amount']:,.2f})" if ev['amount'] > 0 else ""}<br>
            <strong>Verification State:</strong> <span style="color: #FBBF24; font-weight: 700;">{ev['verification_status']}</span><br>
            <strong>Current Disposition:</strong> <code>{ev['resolution_outcome']}</code>
        </div>
    </div>
    """, unsafe_allow_html=True)

    st.markdown("#### Forensics Point Breakdown")
    for sig, pts in ev.get("point_contributions", {}).items():
        st.markdown(f"""
        <div class="signal-tag">
            <span>🔎 {sig}</span>
            <span class="signal-points">+{pts} pts</span>
        </div>
        """, unsafe_allow_html=True)

    st.markdown("#### Automated Rationale")
    st.info(ev["explanation"])

    if ev.get("notes"):
        st.caption(f"Simulator Context: {ev['notes']}")

with disposition_col:
    st.subheader("Analyst Disposition & Decision")

    current_outcome = ev.get("resolution_outcome", "Unresolved")
    outcome_options = ["Confirmed Fraud", "Legitimate", "Unresolved"]
    out_idx = outcome_options.index(current_outcome) if current_outcome in outcome_options else 2

    selected_outcome = st.radio(
        "Formal Classification",
        outcome_options,
        index=out_idx,
        help="Marking as Confirmed Fraud or Legitimate feeds dynamic precision/recall metrics in Analytics",
    )

    analyst_notes_input = st.text_area(
        "Investigative Findings / Notes",
        value=ev.get("analyst_notes", ""),
        placeholder="Document telemetry correlations, customer interview notes, or rationale...",
        height=140,
    )

    if st.button("💾 Commit Investigation Decision", type="primary", use_container_width=True):
        update_investigation_resolution(
            event_id=active_id,
            resolution_outcome=selected_outcome,
            analyst_notes=analyst_notes_input,
            analyst_name=st.session_state.analyst_name,
        )
        st.success(f"✅ Case `{active_id}` successfully committed as '{selected_outcome}' by {st.session_state.analyst_name}.")
        st.rerun()

    st.markdown("<br>", unsafe_allow_html=True)
    st.markdown("#### Direct Response Actions")
    row_btn1, row_btn2 = st.columns(2)
    with row_btn1:
        if st.button("📱 Test Simulated OTP", use_container_width=True):
            st.switch_page("pages/4_OTP_Verification.py")
    with row_btn2:
        if st.button("📞 Test Simulated Call", use_container_width=True):
            st.switch_page("pages/5_Call_Verification.py")

# Case Specific Audit Log
st.markdown("<br>", unsafe_allow_html=True)
st.subheader("Case Audit Log")
case_logs = get_audit_logs(event_id=active_id)
if case_logs:
    st.dataframe(
        [
            {
                "Timestamp": l["timestamp"],
                "Action": l["action_type"],
                "Analyst": l["analyst"],
                "Details": l["details"],
            }
            for l in case_logs
        ],
        use_container_width=True,
        hide_index=True,
    )

render_disclaimer_footer()
