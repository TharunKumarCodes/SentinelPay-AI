"""
SentinelPay AI - Event History & Audit Log
Tagline: Trust the User. Verify the Risk.

Provides a comprehensive, searchable, filterable record of all evaluated events,
score breakdowns, automated policy actions, step-up outcomes, and compliance audit entries.
Includes CSV export capability.
"""

import streamlit as st
import pandas as pd
import json

from core.ui_components import apply_custom_theme, render_header, render_disclaimer_footer, get_band_badge_html
from data.database import get_all_events, get_audit_logs, seed_demo_data

seed_demo_data()
apply_custom_theme()
render_header()

st.title("📜 Event History & Compliance Audit Log")
st.markdown("Immutable record of synthetic telemetry events, automated actions, verification lifecycles, and analyst decisions.")

all_events = get_all_events(limit=250)
all_logs = get_audit_logs(limit=250)

tab_events, tab_audit = st.tabs(["📋 Security Events Log", "🛡️ Compliance Audit Trail"])

with tab_events:
    # Filter Bar
    c_f1, c_f2, c_f3, c_f4 = st.columns(4)
    with c_f1:
        f_band = st.selectbox("Filter Risk Band", ["All Bands", "Low", "Guarded", "Medium", "High", "Critical"])
    with c_f2:
        f_type = st.selectbox("Filter Channel / Type", ["All Types", "Login", "Payment", "PIN attempt"])
    with c_f3:
        f_outcome = st.selectbox("Filter Resolution", ["All Resolutions", "Unresolved", "Legitimate", "Confirmed Fraud"])
    with c_f4:
        search_query = st.text_input("Search ID / Account", placeholder="e.g. EVT- or ACC-")

    filtered = list(all_events)
    if f_band != "All Bands":
        filtered = [e for e in filtered if e["risk_band"] == f_band]
    if f_type != "All Types":
        filtered = [e for e in filtered if e["event_type"] == f_type]
    if f_outcome != "All Resolutions":
        filtered = [e for e in filtered if e["resolution_outcome"] == f_outcome]
    if search_query.strip():
        q = search_query.strip().lower()
        filtered = [
            e for e in filtered
            if q in e["event_id"].lower() or q in e["account_id"].lower() or q in e.get("notes", "").lower()
        ]

    st.markdown(f"**Displaying {len(filtered)} of {len(all_events)} events**")

    if filtered:
        rows = []
        for e in filtered:
            # Flatten signals for readability
            sigs = ", ".join(e.get("triggered_signals", [])) if e.get("triggered_signals") else "None (Baseline)"
            rows.append({
                "Event ID": e["event_id"],
                "Timestamp": e["timestamp"],
                "Account": e["account_id"],
                "Type": e["event_type"],
                "Amount": f"${e['amount']:,.2f}" if e["amount"] > 0 else "—",
                "Score": e["risk_score"],
                "Band": e["risk_band"],
                "Action Taken": e["action_code"],
                "Verification": e["verification_status"],
                "Resolution": e["resolution_outcome"],
                "Triggered Signals": sigs,
            })
        
        df_events = pd.DataFrame(rows)

        st.dataframe(
            df_events,
            use_container_width=True,
            hide_index=True,
            column_config={
                "Score": st.column_config.ProgressColumn(
                    "Score",
                    format="%d",
                    min_value=0,
                    max_value=100,
                ),
            }
        )

        # CSV Download Button
        csv_data = df_events.to_csv(index=False).encode('utf-8')
        c_dl1, c_dl2 = st.columns([1, 3])
        with c_dl1:
            st.download_button(
                label="📥 Export Events (CSV)",
                data=csv_data,
                file_name="sentinelpay_events_export.csv",
                mime="text/csv",
                use_container_width=True,
            )
        with c_dl2:
            inspect_target = st.selectbox(
                "Quick Inspect Event in Risk Analysis",
                [e["event_id"] for e in filtered],
                key="quick_inspect_sel",
            )
            if st.button("🔬 Inspect Selected Event"):
                st.session_state.active_event_id = inspect_target
                st.switch_page("pages/3_Risk_Analysis.py")

    else:
        st.info("No events match the selected filter criteria.")

with tab_audit:
    st.subheader("Global Security Audit Trail")
    st.caption("Captures state transitions, automated rule invocations, MFA challenges, locks, and analyst overrides.")

    if all_logs:
        df_logs = pd.DataFrame([
            {
                "Log ID": l["log_id"],
                "Timestamp": l["timestamp"],
                "Event ID": l["event_id"] if l["event_id"] else "—",
                "Account ID": l["account_id"] if l["account_id"] else "—",
                "Action Type": l["action_type"],
                "Actor / Analyst": l["analyst"],
                "Details": l["details"],
            }
            for l in all_logs
        ])
        st.dataframe(df_logs, use_container_width=True, hide_index=True)

        csv_logs = df_logs.to_csv(index=False).encode('utf-8')
        st.download_button(
            label="📥 Export Audit Trail (CSV)",
            data=csv_logs,
            file_name="sentinelpay_audit_trail_export.csv",
            mime="text/csv",
        )
    else:
        st.info("No audit logs recorded.")

render_disclaimer_footer()
