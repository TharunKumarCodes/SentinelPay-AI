"""
SentinelPay AI - Security Analytics & Fraud Model Metrics
Tagline: Trust the User. Verify the Risk.

Provides aggregate intelligence, risk band distribution, signal frequency
analysis, and machine learning/analyst decision metrics (precision, recall,
false-positive rate) only when supported by labeled ground truth.
"""

import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import time

from core.ui_components import apply_custom_theme, render_header, render_disclaimer_footer
from core.risk_engine import calculate_risk
from data.database import get_all_events, seed_demo_data

seed_demo_data()
apply_custom_theme()
render_header()

st.title("📈 Security Analytics & Fraud Metrics")
st.markdown("Aggregate risk distributions, signal prevalence, and validated model performance metrics.")

events = get_all_events(limit=500)
if not events:
    st.info("No events logged yet.")
    st.stop()

# Benchmark engine latency dynamically
t0 = time.perf_counter()
for _ in range(50):
    calculate_risk(location="Different", device="New", failed_logins=3)
engine_latency_ms = ((time.perf_counter() - t0) / 50) * 1000

# Top KPI row
c1, c2, c3, c4 = st.columns(4)
with c1:
    st.markdown(f"""
    <div class="metric-card">
        <div class="metric-label">Total Events Evaluated</div>
        <div class="metric-value">{len(events)}</div>
        <div class="metric-sub">Across all synthetic channels</div>
    </div>
    """, unsafe_allow_html=True)

with c2:
    avg_score = sum(e["risk_score"] for e in events) / len(events)
    st.markdown(f"""
    <div class="metric-card">
        <div class="metric-label">Average Risk Score</div>
        <div class="metric-value" style="color: #38BDF8;">{avg_score:.1f}<span style="font-size: 1rem; color: #64748B;">/100</span></div>
        <div class="metric-sub">Deterministic weighted average</div>
    </div>
    """, unsafe_allow_html=True)

with c3:
    step_ups = sum(1 for e in events if e["risk_band"] in ("Medium", "High"))
    st.markdown(f"""
    <div class="metric-card">
        <div class="metric-label">MFA Step-Up Rate</div>
        <div class="metric-value" style="color: #FBBF24;">{(step_ups / len(events) * 100):.1f}%</div>
        <div class="metric-sub">OTP (Med) & Voice Call (High)</div>
    </div>
    """, unsafe_allow_html=True)

with c4:
    st.markdown(f"""
    <div class="metric-card">
        <div class="metric-label">Engine Evaluation Latency</div>
        <div class="metric-value" style="color: #34D399;">{engine_latency_ms:.2f} ms</div>
        <div class="metric-sub">Real-time deterministic scoring</div>
    </div>
    """, unsafe_allow_html=True)

st.markdown("<br>", unsafe_allow_html=True)

# Labeled Data & Performance Metrics Section
st.subheader("🎯 Ground Truth Performance Metrics")
st.caption("Calculated dynamically from cases labeled by SOC analysts in the Investigation Center.")

labeled_cases = [e for e in events if e.get("resolution_outcome") in ("Confirmed Fraud", "Legitimate")]
LABELED_MIN_THRESHOLD = 5

if len(labeled_cases) >= LABELED_MIN_THRESHOLD:
    # We define Positive Prediction as High Risk / Step-up or Block (Score >= 50: Medium, High, Critical)
    # Ground Truth: Confirmed Fraud = Positive (1), Legitimate = Negative (0)
    tp = sum(1 for e in labeled_cases if e["risk_score"] >= 50 and e["resolution_outcome"] == "Confirmed Fraud")
    fp = sum(1 for e in labeled_cases if e["risk_score"] >= 50 and e["resolution_outcome"] == "Legitimate")
    fn = sum(1 for e in labeled_cases if e["risk_score"] < 50 and e["resolution_outcome"] == "Confirmed Fraud")
    tn = sum(1 for e in labeled_cases if e["risk_score"] < 50 and e["resolution_outcome"] == "Legitimate")

    precision = (tp / (tp + fp)) * 100 if (tp + fp) > 0 else 0.0
    recall = (tp / (tp + fn)) * 100 if (tp + fn) > 0 else 0.0
    fpr = (fp / (fp + tn)) * 100 if (fp + tn) > 0 else 0.0

    p_col1, p_col2, p_col3, p_col4 = st.columns(4)
    with p_col1:
        st.metric("Labeled Cases", f"{len(labeled_cases)} cases")
    with p_col2:
        st.metric("Precision", f"{precision:.1f}%", help="TP / (TP + FP)")
    with p_col3:
        st.metric("Recall (Detection Rate)", f"{recall:.1f}%", help="TP / (TP + FN)")
    with p_col4:
        st.metric("False Positive Rate", f"{fpr:.1f}%", help="FP / (FP + TN)")

    st.markdown(f"""
    <div style="background: rgba(15, 23, 42, 0.6); border: 1px solid rgba(255,255,255,0.08); border-radius: 8px; padding: 12px 18px; margin-top: 10px; font-size: 0.8rem; color: #94A3B8;">
        <strong>Confusion Matrix Telemetry:</strong> True Positives: <strong style="color: #34D399;">{tp}</strong> |
        False Positives: <strong style="color: #F87171;">{fp}</strong> |
        True Negatives: <strong style="color: #38BDF8;">{tn}</strong> |
        False Negatives: <strong style="color: #FB923C;">{fn}</strong>
    </div>
    """, unsafe_allow_html=True)
else:
    st.markdown(f"""
    <div style="background: rgba(245, 158, 11, 0.1); border: 1px dashed rgba(245, 158, 11, 0.35); border-radius: 8px; padding: 16px 20px; color: #FBBF24;">
        ⚠️ <strong>Not enough labeled data ({len(labeled_cases)}/{LABELED_MIN_THRESHOLD} labeled cases)</strong><br>
        <span style="font-size: 0.82rem; color: #E2E8F0;">
            To calculate statistically meaningful Precision, Recall, and False-Positive Rates, at least {LABELED_MIN_THRESHOLD} events must be classified by an analyst as either <em>Confirmed Fraud</em> or <em>Legitimate</em> in the Investigation Center.
        </span>
    </div>
    """, unsafe_allow_html=True)

st.markdown("<br>", unsafe_allow_html=True)

# Visual Distribution & Signal Correlation Charts
st.subheader("Statistical Visualizations")

chart_row1, chart_row2 = st.columns(2)

with chart_row1:
    st.markdown("#### Risk Score Distribution Histogram")
    scores = [e["risk_score"] for e in events]
    fig_hist = px.histogram(
        scores,
        nbins=20,
        labels={"value": "Risk Score", "count": "Volume"},
        color_discrete_sequence=["#38BDF8"],
    )
    fig_hist.update_layout(
        margin=dict(t=10, b=10, l=10, r=10),
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        font=dict(color="#CBD5E1", family="Outfit"),
        xaxis=dict(range=[0, 100], showgrid=False, title="Risk Score (0-100)"),
        yaxis=dict(showgrid=True, gridcolor="rgba(255,255,255,0.08)", title="Frequency"),
        height=300,
    )
    st.plotly_chart(fig_hist, use_container_width=True)

with chart_row2:
    st.markdown("#### Top Triggered Risk Signals Frequency")
    sig_counts = {}
    for ev in events:
        for s in ev.get("point_contributions", {}).keys():
            sig_counts[s] = sig_counts.get(s, 0) + 1
    
    if sig_counts:
        df_sigs = pd.DataFrame([{"Signal": k, "Count": v} for k, v in sig_counts.items()]).sort_values("Count", ascending=True)
        fig_sig = px.bar(
            df_sigs,
            x="Count",
            y="Signal",
            orientation="h",
            color="Count",
            color_continuous_scale="Viridis",
        )
        fig_sig.update_layout(
            margin=dict(t=10, b=10, l=10, r=10),
            paper_bgcolor="rgba(0,0,0,0)",
            plot_bgcolor="rgba(0,0,0,0)",
            font=dict(color="#CBD5E1", family="Outfit"),
            xaxis=dict(showgrid=True, gridcolor="rgba(255,255,255,0.08)"),
            yaxis=dict(showgrid=False),
            coloraxis_showscale=False,
            height=300,
        )
        st.plotly_chart(fig_sig, use_container_width=True)
    else:
        st.info("No signal anomalies recorded yet.")

render_disclaimer_footer()
