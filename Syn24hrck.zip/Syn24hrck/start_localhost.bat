@echo off
title SentinelPay AI - Local Host Server
echo ======================================================================
echo   Starting SentinelPay AI SOC Operations Dashboard
echo   Tagline: Trust the User. Verify the Risk.
echo ======================================================================
echo.
cd /d "%~dp0"
echo Launching Streamlit server on http://localhost:8505 ...
echo.
python -m streamlit run app.py --server.port 8505
pause
