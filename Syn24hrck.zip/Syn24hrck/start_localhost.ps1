# SentinelPay AI - Local Host Launcher Script (PowerShell)
Write-Host "======================================================================" -ForegroundColor Cyan
Write-Host "  Starting SentinelPay AI Local Host Server..." -ForegroundColor Green
Write-Host "  Tagline: Trust the User. Verify the Risk." -ForegroundColor Yellow
Write-Host "======================================================================" -ForegroundColor Cyan
Write-Host ""
Set-Location -Path $PSScriptRoot
Write-Host "Opening SentinelPay AI on http://localhost:8505 ..." -ForegroundColor Cyan
python -m streamlit run app.py --server.port 8505
