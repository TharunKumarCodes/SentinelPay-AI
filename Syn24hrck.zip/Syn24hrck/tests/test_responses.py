"""
Unit and Integration Tests for Risk Bands, Policies, Verification & Persistence
Validates non-overlapping boundary mappings, OTP/Call state machines,
audit trail logging, and database operations.
"""

import pytest
import os
import uuid
from core.responses import (
    get_band_for_score,
    LOW_BAND,
    GUARDED_BAND,
    MEDIUM_BAND,
    HIGH_BAND,
    CRITICAL_BAND,
)
from core.verification import (
    verify_otp_attempt,
    handle_call_simulation_action,
    DEMO_OTP_CODE,
    MAX_OTP_ATTEMPTS,
)
from core.risk_engine import calculate_risk
from data.database import (
    init_db,
    save_event,
    get_event_by_id,
    get_account,
    lock_account,
    unlock_account,
    update_event_verification,
    update_investigation_resolution,
    get_audit_logs,
    seed_demo_data,
)


class TestBoundaryMappings:
    @pytest.mark.parametrize(
        "score, expected_level, expected_action_code",
        [
            (0, "Low", "ALLOW"),
            (15, "Low", "ALLOW"),
            (29, "Low", "ALLOW"),
            (30, "Guarded", "NOTIFICATION"),
            (40, "Guarded", "NOTIFICATION"),
            (49, "Guarded", "NOTIFICATION"),
            (50, "Medium", "OTP_VERIFICATION"),
            (60, "Medium", "OTP_VERIFICATION"),
            (69, "Medium", "OTP_VERIFICATION"),
            (70, "High", "CALL_VERIFICATION"),
            (80, "High", "CALL_VERIFICATION"),
            (89, "High", "CALL_VERIFICATION"),
            (90, "Critical", "TEMPORARY_BLOCK"),
            (95, "Critical", "TEMPORARY_BLOCK"),
            (100, "Critical", "TEMPORARY_BLOCK"),
        ],
    )
    def test_non_overlapping_exact_boundaries(self, score, expected_level, expected_action_code):
        """Every requested boundary value must map to exactly one correct response."""
        band = get_band_for_score(score)
        assert band.level == expected_level
        assert band.action_code == expected_action_code

    def test_out_of_bounds_clamping(self):
        """Scores below 0 or above 100 must be clamped safely."""
        assert get_band_for_score(-10).level == "Low"
        assert get_band_for_score(150).level == "Critical"


class TestVerificationWorkflows:
    def test_otp_success_flow(self):
        """Entering correct demo code 123456 must return success."""
        res = verify_otp_attempt(DEMO_OTP_CODE, attempts_used=0)
        assert res.success is True
        assert res.status == "VERIFIED"
        assert not res.is_exhausted

    def test_otp_failure_and_exhaustion(self):
        """Wrong code must decrement attempts and trigger EXHAUSTED after max attempts."""
        res1 = verify_otp_attempt("999999", attempts_used=0)
        assert res1.success is False
        assert res1.attempts_remaining == 2
        assert not res1.is_exhausted

        res2 = verify_otp_attempt("999999", attempts_used=1)
        assert res2.success is False
        assert res2.attempts_remaining == 1

        res3 = verify_otp_attempt("999999", attempts_used=2)
        assert res3.success is False
        assert res3.attempts_remaining == 0
        assert res3.is_exhausted is True
        assert res3.status == "EXHAUSTED"

    def test_call_verification_controls(self):
        """Simulated call control buttons must transition state accurately."""
        # Dial call
        dial_res = handle_call_simulation_action("DIAL")
        assert dial_res.status == "WAITING_FOR_CONFIRMATION"
        assert not dial_res.is_terminal

        # Customer pressed 1 (Confirm)
        confirm_res = handle_call_simulation_action("CONFIRM")
        assert confirm_res.status == "VERIFIED"
        assert confirm_res.is_success is True
        assert confirm_res.is_terminal is True

        # Customer pressed 2 (Fraud reported)
        fraud_res = handle_call_simulation_action("REPORT_FRAUD")
        assert fraud_res.status == "FRAUD_REPORTED"
        assert fraud_res.is_success is False
        assert fraud_res.is_terminal is True

        # Call timeout
        timeout_res = handle_call_simulation_action("TIMEOUT")
        assert timeout_res.status == "VERIFICATION_FAILED"
        assert timeout_res.is_success is False


class TestPersistenceAndAuditLogging:
    @pytest.fixture(autouse=True)
    def setup_db(self):
        seed_demo_data()

    def test_preview_and_saved_score_parity(self):
        """The preview score calculation must match the exact saved score."""
        params = {
            "event_type": "Payment",
            "location": "Different",      # +20
            "device": "New",              # +10
            "amount_pattern": "Unusual",  # +15
            "frequency": "Frequent",      # +15 => Total 60 (Medium)
            "failed_logins": 0,
            "incorrect_pins": 0,
            "time_context": "Usual",
            "payment_destination": "Known",
            "amount": 2500.0,
        }

        # Calculate preview
        preview_eval = calculate_risk(**params)
        assert preview_eval.score == 60
        assert preview_eval.band == "Medium"

        test_evt_id = f"EVT-TEST-PARITY-{uuid.uuid4().hex[:8]}"
        saved_id = save_event(
            event_id=test_evt_id,
            account_id="ACC-84920",
            event_type=params["event_type"],
            amount=params["amount"],
            payment_destination="Test Destination",
            location_status=params["location"],
            device_status=params["device"],
            amount_pattern=params["amount_pattern"],
            frequency_status=params["frequency"],
            failed_logins=params["failed_logins"],
            incorrect_pins=params["incorrect_pins"],
            time_status=params["time_context"],
            destination_status=params["payment_destination"],
            notes="Parity test event",
            risk_score=preview_eval.score,
            raw_score=preview_eval.raw_score,
            risk_band=preview_eval.band,
            triggered_signals=preview_eval.triggered_signals,
            point_contributions=preview_eval.point_contributions,
            explanation=preview_eval.explanation,
            recommended_action=preview_eval.recommended_action,
            action_code=preview_eval.action_code,
            analyst_name="Test Analyst",
        )

        # Retrieve saved event
        loaded = get_event_by_id(test_evt_id)
        assert loaded is not None
        assert loaded["risk_score"] == preview_eval.score
        assert loaded["risk_band"] == preview_eval.band
        assert loaded["action_code"] == preview_eval.action_code
        assert loaded["point_contributions"] == preview_eval.point_contributions

    def test_critical_block_locks_account_automatically(self):
        """Critical risk score (90-100) must lock the associated demo account."""
        acc_id = "ACC-19342"
        # Ensure initial state unlocked
        unlock_account(acc_id, "Reset for test", "Admin")
        assert get_account(acc_id)["is_locked"] == 0

        # Submit critical event
        crit_eval = calculate_risk(
            event_type="Payment",
            location="Different",        # 20
            device="New",                # 10
            amount_pattern="Unusual",    # 15
            frequency="Frequent",        # 15
            failed_logins=4,             # 20
            incorrect_pins=3,            # 20 => Total 100
        )
        assert crit_eval.score >= 90

        test_crit_id = f"EVT-CRIT-TEST-{uuid.uuid4().hex[:8]}"
        save_event(
            event_id=test_crit_id,
            account_id=acc_id,
            event_type="Payment",
            amount=9999.0,
            payment_destination="Malicious Node",
            location_status="Different",
            device_status="New",
            amount_pattern="Unusual",
            frequency_status="Frequent",
            failed_logins=4,
            incorrect_pins=3,
            time_status="Unusual",
            destination_status="New",
            notes="Simulated takeover attempt",
            risk_score=crit_eval.score,
            raw_score=crit_eval.raw_score,
            risk_band=crit_eval.band,
            triggered_signals=crit_eval.triggered_signals,
            point_contributions=crit_eval.point_contributions,
            explanation=crit_eval.explanation,
            recommended_action=crit_eval.recommended_action,
            action_code=crit_eval.action_code,
            analyst_name="Circuit Breaker",
        )

        acc = get_account(acc_id)
        assert acc["is_locked"] == 1
        assert "Critical risk score" in acc["lock_reason"]

        # Verify audit logs captured the account lock
        logs = get_audit_logs(account_id=acc_id)
        assert any(l["action_type"] == "ACCOUNT_LOCKED" for l in logs)

        # Unlock account and test restoration
        unlock_account(acc_id, "Manual Analyst Review Passed", "Sarah Vance")
        assert get_account(acc_id)["is_locked"] == 0
