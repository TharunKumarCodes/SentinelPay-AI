"""
Unit and Integration Tests for SentinelPay AI Risk Engine
Validates all scoring boundaries, signal contributions, state idempotence,
and boundary enforcement according to specification.
"""

import pytest
from core.risk_engine import calculate_risk, DEFAULT_WEIGHTS, DEFAULT_THRESHOLDS
from core.responses import get_band_for_score, LOW_BAND, GUARDED_BAND, MEDIUM_BAND, HIGH_BAND, CRITICAL_BAND


class TestRiskEngineScoring:
    def test_baseline_zero_score(self):
        """Normal login with baseline known properties must score 0 (Low)."""
        eval_res = calculate_risk(
            event_type="Login",
            location="Usual",
            device="Known",
            amount_pattern="Usual",
            frequency="Normal",
            failed_logins=0,
            incorrect_pins=0,
            time_context="Usual",
            payment_destination="Known",
        )
        assert eval_res.score == 0
        assert eval_res.band == "Low"
        assert len(eval_res.triggered_signals) == 0
        assert eval_res.action_code == "ALLOW"
        assert not eval_res.requires_step_up
        assert not eval_res.is_blocked

    def test_different_location_increase_and_removal(self):
        """Selecting Different location must increase score by 20; switching back must remove it."""
        # 1. Baseline
        base = calculate_risk(location="Usual")
        assert base.score == 0

        # 2. Select Different location (+20)
        elevated = calculate_risk(location="Different")
        assert elevated.score == 20
        assert "Different Location" in elevated.point_contributions
        assert elevated.point_contributions["Different Location"] == 20
        assert elevated.band == "Low"  # 20 is within 0-29 Low

        # 3. Switch back to Usual location -> Must recalculate to 0 without residual accumulation
        reverted = calculate_risk(location="Usual")
        assert reverted.score == 0
        assert "Different Location" not in reverted.point_contributions

    def test_individual_signal_contributions(self):
        """Each signal must contribute its exact configured point weight."""
        # New device (+10)
        res = calculate_risk(device="New")
        assert res.score == 10
        assert res.point_contributions["New Device"] == 10

        # Unusual amount (+15)
        res = calculate_risk(amount_pattern="Unusual")
        assert res.score == 15
        assert res.point_contributions["Unusual Amount"] == 15

        # Monetary amount threshold ($5000+) on payment (+15)
        res = calculate_risk(event_type="Payment", amount=6500.0)
        assert res.score == 15
        assert res.point_contributions["Unusual Amount"] == 15

        # Frequent transactions (+15)
        res = calculate_risk(frequency="Frequent")
        assert res.score == 15
        assert res.point_contributions["Frequent Transactions"] == 15

        # Failed logins count below threshold (2 < 3) => 0 pts
        res = calculate_risk(failed_logins=2)
        assert res.score == 0

        # Failed logins count at or above threshold (3 >= 3) => +20 pts
        res = calculate_risk(failed_logins=3)
        assert res.score == 20
        assert any("Failed Logins" in k for k in res.point_contributions)

        # Incorrect PINs below threshold (1 < 2) => 0 pts
        res = calculate_risk(incorrect_pins=1)
        assert res.score == 0

        # Incorrect PINs at or above threshold (2 >= 2) => +20 pts
        res = calculate_risk(incorrect_pins=2)
        assert res.score == 20
        assert any("Incorrect PINs" in k for k in res.point_contributions)

        # Unusual timing (+10)
        res = calculate_risk(time_context="Unusual")
        assert res.score == 10
        assert res.point_contributions["Unusual Time"] == 10

        # New destination (+10)
        res = calculate_risk(payment_destination="New")
        assert res.score == 10
        assert res.point_contributions["New Destination"] == 10

    def test_score_remains_within_0_to_100(self):
        """Combining all suspicious signals (sum 120) must be capped strictly at 100."""
        all_signals = calculate_risk(
            event_type="Payment",
            location="Different",        # 20
            device="New",                # 10
            amount_pattern="Unusual",    # 15
            frequency="Frequent",        # 15
            failed_logins=5,             # 20
            incorrect_pins=4,            # 20
            time_context="Unusual",      # 10
            payment_destination="New",   # 10
        )
        assert all_signals.raw_score == 120
        assert all_signals.score == 100
        assert all_signals.band == "Critical"
        assert all_signals.is_blocked
        assert all_signals.action_code == "TEMPORARY_BLOCK"

    def test_recalculates_without_duplicate_accumulation(self):
        """Calling calculate_risk repeatedly with identical inputs must return identical scores."""
        r1 = calculate_risk(location="Different", device="New")
        r2 = calculate_risk(location="Different", device="New")
        r3 = calculate_risk(location="Different", device="New")
        assert r1.score == 30
        assert r2.score == 30
        assert r3.score == 30

    def test_turning_off_signals_decreases_score(self):
        """Progressively removing signals decreases score deterministically."""
        s4 = calculate_risk(location="Different", device="New", frequency="Frequent", time_context="Unusual")
        assert s4.score == 55  # 20 + 10 + 15 + 10 = 55 (Medium)

        # Remove frequency (-15)
        s3 = calculate_risk(location="Different", device="New", frequency="Normal", time_context="Unusual")
        assert s3.score == 40  # 55 - 15 = 40 (Guarded)

        # Remove location (-20)
        s2 = calculate_risk(location="Usual", device="New", frequency="Normal", time_context="Unusual")
        assert s2.score == 20  # 40 - 20 = 20 (Low)

        # Remove all
        s0 = calculate_risk(location="Usual", device="Known", frequency="Normal", time_context="Usual")
        assert s0.score == 0
