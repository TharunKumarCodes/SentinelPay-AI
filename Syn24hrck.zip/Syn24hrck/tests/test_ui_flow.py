"""
Streamlit AppTest Automated UI Flow Verification for SentinelPay AI
Validates primary acceptance criteria:
1. Baseline Normal login yields Low risk score (0).
2. Changing location to 'Different' increases score immediately (+20).
3. Switching back to 'Usual' removes the location points.
4. Adding failed logins beyond threshold increases score.
5. Testing one-click scenario presets across all 5 risk tiers.
"""

import pytest
import os
from streamlit.testing.v1 import AppTest
from data.database import seed_demo_data

SIMULATOR_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "pages", "2_Event_Simulator.py")


class TestEventSimulatorUI:
    @pytest.fixture(autouse=True)
    def setup_data(self):
        seed_demo_data()

    def test_simulator_reactive_scoring(self):
        """Tests that changing inputs in the simulator updates the score reactively."""
        at = AppTest.from_file(SIMULATOR_PATH).run()
        assert not at.exception

        # Initial baseline check
        assert at.session_state.sim_location == "Usual"
        assert at.session_state.sim_failed_logins == 0

        # Change location to 'Different'
        at.radio(key="sim_location").set_value("Different").run()
        assert not at.exception
        assert at.session_state.sim_location == "Different"

        # Change location back to 'Usual'
        at.radio(key="sim_location").set_value("Usual").run()
        assert not at.exception
        assert at.session_state.sim_location == "Usual"

    def test_failed_logins_threshold_reactivity(self):
        """Increasing failed logins above threshold increases score."""
        at = AppTest.from_file(SIMULATOR_PATH).run()
        assert not at.exception

        # Set failed logins to 3 (threshold is >= 3)
        at.slider(key="sim_failed_logins").set_value(3).run()
        assert not at.exception
        assert at.session_state.sim_failed_logins == 3

        # Set back to 0
        at.slider(key="sim_failed_logins").set_value(0).run()
        assert not at.exception
        assert at.session_state.sim_failed_logins == 0

    def test_one_click_scenarios(self):
        """Clicking scenario buttons properly updates session state."""
        at = AppTest.from_file(SIMULATOR_PATH).run()
        assert not at.exception

        # Click scenario 2 (Guarded)
        btn_guarded = next(b for b in at.button if "sc_btn_scenario_guarded_travel" in b.key)
        btn_guarded.click().run()
        assert not at.exception
        assert at.session_state.sim_location == "Different"
        assert at.session_state.sim_time_context == "Unusual"

        # Click scenario 5 (Critical)
        btn_crit = next(b for b in at.button if "sc_btn_scenario_critical_lock" in b.key)
        btn_crit.click().run()
        assert not at.exception
        assert at.session_state.sim_location == "Different"
        assert at.session_state.sim_failed_logins == 4
        assert at.session_state.sim_incorrect_pins == 3
